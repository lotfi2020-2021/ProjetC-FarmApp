#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "employer.h"



int choix[]={0,0,0,0,0,0,0};
int choix1[]={0,0,0,0,0,0,0};

char x[20];
void
on_connecter_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *login, *mdp ;
char user[20];
char pasw[20];

char user1[20];
char pasw1[20];
int trouve;
login=lookup_widget (button,"login");
mdp=lookup_widget (button,"mdp");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(mdp)));
FILE *f;


f=fopen("user.txt","r");

while(fscanf(f,"%s %s \n",user1,pasw1)!=EOF){
if((strcmp(user,user1)==0)&&(strcmp(pasw,pasw1)==0))
{
GtkWidget *authentification;
authentification=lookup_widget(button,"authentification");
gtk_widget_destroy(authentification);
GtkWidget *gestion;
gestion = create_gestion ();

  gtk_widget_show (gestion);
GtkPixmap *image55;
image55 = GTK_PIXMAP(lookup_widget (button ,"image55"));
gtk_widget_show (image55);
  
}
else
{GtkWidget *erreur;
erreur = create_erreur ();
  gtk_widget_show (erreur);
}
}}


void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_annuler2_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouter_clicked                     (GtkButton	*button,
                                        gpointer         user_data)
{

GtkWidget *finajouter;

GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *cin;
GtkWidget *email;
GtkWidget *tel;
GtkWidget *jj;
GtkWidget *mm;
GtkWidget *aa;
GtkWidget *poste;
GtkWidget *salaire;


employer p;



nom = lookup_widget (button ,"nom");
prenom = lookup_widget (button ,"prenom");
cin = lookup_widget (button ,"cin");
email = lookup_widget (button ,"email");
tel = lookup_widget (button ,"tel");
poste = lookup_widget (button ,"poste");
jj = lookup_widget (button ,"jj");
mm = lookup_widget (button ,"mm");
aa = lookup_widget (button ,"aa");
salaire = lookup_widget (button ,"salaire");

p.dd.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.dd.moin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.dd.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));

strcpy(p.nomm, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(p.prenomm, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(p.emaill, gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(p.postee, gtk_combo_box_get_active_text(GTK_COMBO_BOX(poste)));
strcpy(p.cinn, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(p.tell, gtk_entry_get_text(GTK_ENTRY(tel)));
strcpy(p.salairee, gtk_entry_get_text(GTK_ENTRY(salaire)));
int b=0;
p.jt=0;
p.ja=0;
strcpy(p.etat,"....");

GtkWidget *cin_exist;
cin_exist = lookup_widget (button ,"cin_exist");
GtkWidget *erreur_cin;
erreur_cin = lookup_widget (button ,"erreur_cin");
GtkWidget *erreur_tel;
erreur_tel = lookup_widget (button ,"erreur_tel");
GtkWidget *erreur_salaire;
erreur_salaire = lookup_widget (button ,"erreur_salaire");
GtkWidget *erreur_email;
erreur_email = lookup_widget (button ,"erreur_email");
GtkWidget *erreur_nom;
erreur_nom = lookup_widget (button ,"erreur_nom");
GtkWidget *erreur_prenom;
erreur_prenom = lookup_widget (button ,"erreur_prenom");
GtkWidget *erreur_poste;
erreur_poste = lookup_widget (button ,"erreur_poste");
/*gtk_widget_hide(erreur_cin);
gtk_widget_hide(erreur_tel);
gtk_widget_hide(erreur_salaire);
gtk_widget_hide(erreur_email);
gtk_widget_hide(erreur_nom);
gtk_widget_hide(erreur_prenom);
gtk_widget_hide(erreur_poste);*/
if (existe_employer (p.cinn)==0 ){b=1;
	          gtk_widget_show (cin_exist);
}
else {
		  gtk_widget_hide(cin_exist);
}
if (verifier_cin (p.cinn)==0 || (strcmp(p.cinn,"")==0)){b=1;
	          gtk_widget_show (erreur_cin);
}
else {
		  gtk_widget_hide(erreur_cin);
}
if (verifier_cin (p.tell)==0 || (strcmp(p.tell,"")==0)){b=1;
	          gtk_widget_show (erreur_tel);

}
else {
		  gtk_widget_hide(erreur_tel);
}	
if (verifier_salaire (p.salairee)== 0 || (strcmp(p.salairee,"")==0)){b=1;
	gtk_widget_show (erreur_salaire);

}
else {
		  gtk_widget_hide(erreur_salaire);
}
if (verifier_email (p.emaill)==0 || (strcmp(p.emaill,"")==0) ){b=1;
	gtk_widget_show (erreur_email);

}
else {
		  gtk_widget_hide(erreur_email);
}
if (verifier_lettre (p.nomm)==0 || (strcmp(p.nomm,"")==0) ){b=1;
	gtk_widget_show (erreur_nom);

}
else {
		  gtk_widget_hide(erreur_nom);
}
if (verifier_lettre (p.prenomm)==0 || (strcmp(p.prenomm,"")==0) ){b=1;
	gtk_widget_show (erreur_prenom);

}
else {
		  gtk_widget_hide(erreur_prenom);
}
if(strcmp(p.postee,"")==0){b=1;
	gtk_widget_show (erreur_poste);

}
else {
		  gtk_widget_hide(erreur_poste);
}	  
if (b == 0){
ajouter(p);
emploi (choix, p);
GtkWidget *wajouter;
wajouter=lookup_widget(button,"wajouter");
gtk_widget_destroy(wajouter);
finajouter = create_ajouterfin ();
  gtk_widget_show (finajouter);}
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}
void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *wsupprimer;
wsupprimer=lookup_widget(button,"wsupprimer");
gtk_widget_destroy(wsupprimer);
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);
}

void
on_annuler1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *wajouter;
wajouter=lookup_widget(button,"wajouter");
gtk_widget_destroy(wajouter);
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);

GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);
}





void
on_annuler_3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);

}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *supp;
GtkWidget *comm;


char com[20];
supp = lookup_widget (button ,"supp");


strcpy(x , gtk_entry_get_text(GTK_ENTRY(supp)));

printf("%s",x);
GtkWidget *wsupprimer;
wsupprimer=lookup_widget(button,"wsupprimer");
gtk_widget_destroy(wsupprimer);

}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *finmodifier;
 GtkWidget *nom1;
  GtkWidget *prenom1;
  GtkWidget *cin1;
  GtkWidget *email1;
  GtkWidget *tel1;
  GtkWidget *poste1;
  GtkWidget *jj1;
  GtkWidget *mm1;
  GtkWidget *aa1;
  GtkWidget *salaire1;
employer a;

int b =0;
nom1 = lookup_widget (button ,"nom1");
prenom1 = lookup_widget (button ,"prenom1");
cin1 = lookup_widget (button ,"cin1");
email1 = lookup_widget (button ,"email1");
tel1 = lookup_widget (button ,"tel1");
poste1 = lookup_widget (button ,"poste1");
jj1 = lookup_widget (button ,"jj1");
mm1 = lookup_widget (button ,"mm1");
aa1 = lookup_widget (button ,"aa1");
salaire1 = lookup_widget (button ,"salaire1");
a.dd.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj1));
a.dd.moin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm1));
a.dd.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa1));

strcpy(a.nomm, gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(a.prenomm, gtk_entry_get_text(GTK_ENTRY(prenom1)));
strcpy(a.emaill, gtk_entry_get_text(GTK_ENTRY(email1)));
strcpy(a.postee, gtk_combo_box_get_active_text(GTK_COMBO_BOX(poste1)));
strcpy(a.cinn, gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(a.tell, gtk_entry_get_text(GTK_ENTRY(tel1)));
strcpy(a.salairee, gtk_entry_get_text(GTK_ENTRY(salaire1)));


GtkWidget *cin_exist1;
cin_exist1 = lookup_widget (button ,"cin_exist1");
GtkWidget *erreur_cin;
erreur_cin = lookup_widget (button ,"erreur_cin1");
GtkWidget *erreur_tel;
erreur_tel = lookup_widget (button ,"erreur_tel1");
GtkWidget *erreur_salaire;
erreur_salaire = lookup_widget (button ,"erreur_salaire1");
GtkWidget *erreur_email;
erreur_email = lookup_widget (button ,"erreur_email1");
GtkWidget *erreur_nom;
erreur_nom = lookup_widget (button ,"erreur_nom1");
GtkWidget *erreur_prenom;
erreur_prenom = lookup_widget (button ,"erreur_prenom1");
GtkWidget *erreur_poste;
erreur_poste = lookup_widget (button ,"erreur_poste1");
/*gtk_widget_hide(erreur_cin);
gtk_widget_hide(erreur_tel);
gtk_widget_hide(erreur_salaire);
gtk_widget_hide(erreur_email);
gtk_widget_hide(erreur_nom);
gtk_widget_hide(erreur_prenom);
gtk_widget_hide(erreur_poste);*/


if (verifier_cin (a.cinn)==0 || (strcmp(a.cinn,"")==0)){b=1;
	          gtk_widget_show (erreur_cin);
}
else {
		  gtk_widget_hide(erreur_cin);
}
if (verifier_cin (a.tell)==0 || (strcmp(a.tell,"")==0)){b=1;
	          gtk_widget_show (erreur_tel);

}
else {
		  gtk_widget_hide(erreur_tel);
}	
if (verifier_salaire (a.salairee)== 0 || (strcmp(a.salairee,"")==0)){b=1;
	gtk_widget_show (erreur_salaire);

}
else {
		  gtk_widget_hide(erreur_salaire);
}
if (verifier_email (a.emaill)==0 || (strcmp(a.emaill,"")==0) ){b=1;
	gtk_widget_show (erreur_email);

}
else {
		  gtk_widget_hide(erreur_email);
}
if (verifier_lettre (a.nomm)==0 || (strcmp(a.nomm,"")==0) ){b=1;
	gtk_widget_show (erreur_nom);

}
else {
		  gtk_widget_hide(erreur_nom);
}
if (verifier_lettre (a.prenomm)==0 || (strcmp(a.prenomm,"")==0) ){b=1;
	gtk_widget_show (erreur_prenom);

}
else {
		  gtk_widget_hide(erreur_prenom);
}
if(strcmp(a.postee,"")==0){b=1;
	gtk_widget_show (erreur_poste);

}
else {
		  gtk_widget_hide(erreur_poste);
}	  
if (b == 0){
modifier (a,o);
modifier_emploi (a ,o , choix1);
GtkWidget *wmodifier;
wmodifier=lookup_widget(button,"wmodifier");
gtk_widget_destroy(wmodifier);
finmodifier = create_modifierfin ();
  gtk_widget_show (finmodifier);}
} 



void
on_annuler_4_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *wmodifier;
wmodifier=lookup_widget(button,"wmodifier");
gtk_widget_destroy(wmodifier);
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);
GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);

}


void
on_go_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *acuille;
acuille=lookup_widget(button,"acuille");
gtk_widget_destroy(acuille);
GtkWidget *wajouter;
wajouter = create_wajouter ();
  gtk_widget_show (wajouter);
GtkWidget *cin_exist;
cin_exist = lookup_widget (wajouter ,"cin_exist");
GtkWidget *erreur_cin;
erreur_cin = lookup_widget (wajouter ,"erreur_cin");
GtkWidget *erreur_tel;
erreur_tel = lookup_widget (wajouter ,"erreur_tel");
GtkWidget *erreur_salaire;
erreur_salaire = lookup_widget (wajouter ,"erreur_salaire");
GtkWidget *erreur_email;
erreur_email = lookup_widget (wajouter ,"erreur_email");
GtkWidget *erreur_nom;
erreur_nom = lookup_widget (wajouter ,"erreur_nom");
GtkWidget *erreur_prenom;
erreur_prenom = lookup_widget (wajouter ,"erreur_prenom");
GtkWidget *erreur_poste;
erreur_poste = lookup_widget (wajouter ,"erreur_poste");
gtk_widget_hide(erreur_cin);
gtk_widget_hide(erreur_tel);
gtk_widget_hide(erreur_salaire);
gtk_widget_hide(erreur_email);
gtk_widget_hide(erreur_nom);
gtk_widget_hide(erreur_prenom);
gtk_widget_hide(erreur_poste);
gtk_widget_hide(cin_exist);
}


void
on_go_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acuille;
acuille=lookup_widget(button,"acuille");
gtk_widget_destroy(acuille);
GtkWidget *confirmesupprimer;
confirmesupprimer = create_confirmesupprimer ();
  gtk_widget_show (confirmesupprimer);

}


void
on_go_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *acuille;
acuille=lookup_widget(button,"acuille");
gtk_widget_destroy(acuille);
GtkWidget *wmodifier;
 wmodifier = create_wmodifier ();
  gtk_widget_show (wmodifier);

employer c;
FILE *f;
f=fopen("employer.txt","r");
if(f==NULL)
 {
     return;
}else
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",c.cinn,c.nomm,c.prenomm,c.emaill,c.tell,c.postee,c.salairee,&c.dd.jour,&c.dd.moin,&c.dd.anne,&c.jt,&c.ja,c.etat)!=EOF)
{ if (strcmp(c.cinn,o.cinn)==0){
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"cin1")),c.cinn);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"nom1")),c.nomm);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"prenom1")),c.prenomm);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"email1")),c.emaill);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"tel1")),c.tell);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"salaire1")),c.salairee);
}}
GtkWidget *cin_exist1;
cin_exist1 = lookup_widget (wmodifier ,"cin_exist1");
GtkWidget *erreur_cin1;
erreur_cin1 = lookup_widget (wmodifier ,"erreur_cin1");
GtkWidget *erreur_tel1;
erreur_tel1 = lookup_widget (wmodifier ,"erreur_tel1");
GtkWidget *erreur_salaire1;
erreur_salaire1 = lookup_widget (wmodifier ,"erreur_salaire1");
GtkWidget *erreur_email1;
erreur_email1 = lookup_widget (wmodifier ,"erreur_email1");
GtkWidget *erreur_nom1;
erreur_nom1 = lookup_widget (wmodifier ,"erreur_nom1");
GtkWidget *erreur_prenom1;
erreur_prenom1 = lookup_widget (wmodifier ,"erreur_prenom1");
GtkWidget *erreur_poste1;
erreur_poste1 = lookup_widget (wmodifier ,"erreur_poste1");
gtk_widget_hide(erreur_cin1);
gtk_widget_hide(erreur_tel1);
gtk_widget_hide(erreur_salaire1);
gtk_widget_hide(erreur_email1);
gtk_widget_hide(erreur_nom1);
gtk_widget_hide(erreur_prenom1);
gtk_widget_hide(erreur_poste1);
gtk_widget_hide(cin_exist1);
}


void
on_go_aff_clicked                      (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *treeview1;
GtkWidget *acuille;
acuille=lookup_widget(button,"acuille");
gtk_widget_show(acuille);
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
}


void
on_ok1_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *ajouterfin;
ajouterfin=lookup_widget(button,"ajouterfin");
gtk_widget_destroy(ajouterfin);


GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);
GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);
}



void
on_ok3_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *modifierfin;
modifierfin=lookup_widget(button,"modifierfin");
gtk_widget_destroy(modifierfin);



GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);

GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);
}


void
on_ok2_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *supprimerfin;
supprimerfin=lookup_widget(button,"supprimerfin");
gtk_widget_hide(supprimerfin);
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);
GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);
}


void
on_confirmer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer(o);
 supprimer_emploi(o);
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"confirmesupprimer");
gtk_widget_destroy(confirmesupprimer);
GtkWidget *supprimerfin;
supprimerfin = create_supprimerfin ();
  gtk_widget_show (supprimerfin);
}


void
on_annuler11_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"confirmesupprimer");
gtk_widget_destroy(confirmesupprimer);
GtkWidget *wsupprimer;
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);

GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);
 

}

void
on_okk_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *erreur;
erreur=lookup_widget(button,"erreur");
gtk_widget_destroy(erreur);
}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* email;
	gchar* tel;
	gchar* cin;
	gchar* poste;
	gchar* salaire;
	gchar* jtt;
	gchar* jaa;
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &cin, 1, &nom,2,&prenom,3,&email,4,&tel,5,&poste,6,&salaire,7,&jtt,8,&jaa,-1);
	strcpy(o.cinn,cin);  
	
	}
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *chercher1;  
char ch[20];
chercher1=lookup_widget (button,"chercher1");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(chercher1)));
GtkWidget *treeview1;
GtkWidget *acuille;

acuille=lookup_widget(button,"acuille");
gtk_widget_show(acuille);
treeview1=lookup_widget(acuille,"treeview1");
chercher(treeview1,ch);

}





void
on_controle_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *controle;

controle = create_controle ();
  gtk_widget_show (controle);





}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* email;
	gchar* tel;
	gchar* cin;
	gchar* poste;
	gchar* salaire;
	gchar* jtt;
	gchar* jaa;
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &cin, 1, &nom,2,&prenom,3,&email,4,&tel,5,&poste,6,&salaire,7,&jtt,8,&jaa,-1);
	strcpy(n.cinn,cin);  
	
	}

}


void
on_present_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
presente (n);
GtkWidget *treeview2_sabri;

treeview2_sabri=lookup_widget(button,"treeview2_sabri");
afficher2(treeview2_sabri);
}




void
on_retourP_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_absente_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
absente (n);


GtkWidget *treeview2_sabri;

treeview2_sabri=lookup_widget(button,"treeview2_sabri");
afficher2(treeview2_sabri);
}


void
on_actualiser_activate                 (GtkButton       *button,
                                        gpointer         user_data)
{


}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{retour();


GtkWidget *acuille;
GtkWidget *labelverifenreg;
labelverifenreg=lookup_widget(button,"labelverifenreg");
gtk_widget_hide (labelverifenreg);

GtkWidget *treeview2_sabri;
GtkWidget *controle;
controle=lookup_widget(button,"controle");
gtk_widget_show(controle);
treeview2_sabri=lookup_widget(button,"treeview2_sabri");
afficher2(treeview2_sabri);

}


void
on_okmeilleur_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *meilleur;
meilleur=lookup_widget(button,"meilleur");
gtk_widget_destroy(meilleur);

}


void
on_meilleur_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{ 
GtkWidget *meilleur;

meilleur = create_meilleur ();
  gtk_widget_show (meilleur);

employer t;
t = meilleur_employer();
strcat(t.nomm," ");strcat(t.nomm,t.prenomm);
GtkWidget* labelemployer;

labelemployer = lookup_widget(button, "labelemployer") ;

gtk_label_set_text(GTK_LABEL(labelemployer),t.nomm);

}


void
on_aaa_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{employer t;
t = meilleur_employer();
strcat(t.nomm," ");strcat(t.nomm,t.prenomm);
GtkWidget* labelemployer;

labelemployer = lookup_widget(button, "labelemployer") ;

gtk_label_set_text(GTK_LABEL(labelemployer),t.nomm);
}


void
on_hemeee_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_gestion_emplyer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{



GtkWidget *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
GtkWidget *acuille;
acuille = create_acuille ();
  gtk_widget_show (acuille);
GtkWidget *treeview1;
treeview1=lookup_widget(acuille,"treeview1");
afficher(treeview1);
GtkWidget *treeview5;
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
GtkWidget *treeview2_sabri;
treeview2_sabri=lookup_widget(acuille,"treeview2_sabri");
afficher2(treeview2_sabri);
GtkWidget *treeview6;
treeview6=lookup_widget(acuille,"treeview6");
afficher_emploi(treeview6);

GtkWidget *labelverifenreg;
labelverifenreg=lookup_widget(acuille,"labelverifenreg");
gtk_widget_hide (labelverifenreg);

GtkWidget *labeldateex;
labeldateex=lookup_widget(acuille,"labeldateex");
gtk_widget_hide (labeldateex);
}

void
on_gestion_capteur_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestion_troupaux_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestion_equipements_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_gestion_clients_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_Enregistrer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *labelverifenreg;
labelverifenreg = lookup_widget (button ,"labelverifenreg");
char a[5];
char b[5];
char c[5];
char y[15]="";

int aa,mm,jj;
GtkWidget *calendar;
calendar=lookup_widget(button,"calendar1");
gtk_calendar_get_date (GTK_CALENDAR(calendar),
                       &aa,
                       &mm,
                       &jj);
mm=mm+1;


sprintf(a,"%d",jj);sprintf(b,"%d",mm);sprintf(c,"%d",aa);
strcat(y,a);strcat(y,"-");strcat(y,b);strcat(y,"-");strcat(y,c);
int z=verifier_enreg (y);
if (z == 1 )
//gtk_label_set_text(GTK_LABEL(labelverifenreg),"Date est déja enrigistre");
gtk_widget_show (labelverifenreg);
else {
save(y);
retour();

GtkWidget *fincontrole;


fincontrole = create_fincontrole ();
  gtk_widget_show (fincontrole);}
}


void
on_oksave_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fincontrole;
fincontrole=lookup_widget(button,"fincontrole");
gtk_widget_destroy(fincontrole);
GtkWidget *treeview2_sabri;

treeview2_sabri=lookup_widget(button,"treeview2_sabri");
afficher2(treeview2_sabri);
}



void
on_historique_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

int aa,mm,jj;



GtkWidget *treeview4;
GtkWidget *objet;
char a[5];
char b[5];
char c[5];
char y[15]="";

GtkWidget *calendar;
calendar=lookup_widget(button,"calendar2");
gtk_calendar_get_date (GTK_CALENDAR(calendar),
                       &aa,
                       &mm,
                       &jj);

mm=mm+1;



sprintf(a,"%d",jj);sprintf(b,"%d",mm);sprintf(c,"%d",aa);
strcat(y,a);strcat(y,"-");strcat(y,b);strcat(y,"-");strcat(y,c);


treeview4=lookup_widget(button,"treeview4");
historique_date(treeview4,y);
}


void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* email;
	gchar* tel;
	gchar* cin;
	gchar* poste;
	gchar* salaire;
	gchar* jtt;
	gchar* jaa;
	
	
	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &cin, 1, &nom,2,&prenom,3,&email,4,&tel,5,&poste,6,&salaire,7,&jtt,8,&jaa,-1);
	strcpy(o.cinn,cin);  
	GtkWidget *treeview4;
treeview4=lookup_widget(treeview,"treeview4");
	historique_employer(treeview4 , o.cinn);
GtkWidget *labeldateex;
labeldateex=lookup_widget(treeview,"labeldateex");
gtk_widget_hide (labeldateex);
}
	}


void
on_rechercher2_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *rechercher2;  
char ch[20];
rechercher2=lookup_widget (button,"rechercher2");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(rechercher2)));
GtkWidget *treeview5;
GtkWidget *acuille;

acuille=lookup_widget(button,"acuille");
gtk_widget_show(acuille);
treeview5=lookup_widget(acuille,"treeview5");
chercher(treeview5,ch);
}


void
on_actualier_historique_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview5;
GtkWidget *acuille;
acuille=lookup_widget(button,"acuille");
gtk_widget_show(acuille);
treeview5=lookup_widget(acuille,"treeview5");
afficher(treeview5);
}


void
on_test_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *treeview4;
treeview4=lookup_widget(button,"treeview4");
	historique_employer(treeview4 , o.cinn);
}





void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[0]=1;
else choix[0]=0;
}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[1]=1;
else choix[1]=0;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[2]=1;
else choix[2]=0;
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[3]=1;
else choix[3]=0;
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[4]=1;
else choix[4]=0;
}


void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[5]=1;
else choix[5]=0;
}


void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[6]=1;
else choix[6]=0;
}


void
on_act_emploi_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *acuille;
GtkWidget *treeview6;
treeview6=lookup_widget(button,"treeview6");
afficher_emploi(treeview6);
}


void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[0]=1;
else choix1[0]=0;
}


void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[1]=1;
else choix1[1]=0;
}


void
on_checkbutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[2]=1;
else choix1[2]=0;
}


void
on_checkbutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[3]=1;
else choix1[3]=0;
}


void
on_checkbutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[4]=1;
else choix1[4]=0;
}


void
on_checkbutton13_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[5]=1;
else choix1[5]=0;
}


void
on_checkbutton14_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1[6]=1;
else choix1[6]=0;
}


void
on_ETUNDRE_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_calendar2_day_selected_double_click (GtkCalendar     *calendar,
                                        gpointer         user_data)
{
int aa,mm,jj;


GtkWidget *labeldateex;
labeldateex = lookup_widget (calendar ,"labeldateex");

GtkWidget *treeview4;
GtkWidget *objet;
char a[5];
char b[5];
char c[5];
char y[15]="";

GtkButton *button;
calendar=lookup_widget(calendar,"calendar2");
gtk_calendar_get_date (GTK_CALENDAR(calendar),
                       &aa,
                       &mm,
                       &jj);

mm=mm+1;



sprintf(a,"%d",jj);sprintf(b,"%d",mm);sprintf(c,"%d",aa);
strcat(y,a);strcat(y,"-");strcat(y,b);strcat(y,"-");strcat(y,c);
int z=verifier_enreg (y);
if (z == 0 )
//gtk_label_set_text(GTK_LABEL(labelverifenreg),"Date est déja enrigistre");
gtk_widget_show (labeldateex);
else {

treeview4=lookup_widget(calendar,"treeview4");
historique_date(treeview4,y);
GtkWidget *labeldateex;
labeldateex=lookup_widget(calendar,"labeldateex");
gtk_widget_hide (labeldateex);}
}

