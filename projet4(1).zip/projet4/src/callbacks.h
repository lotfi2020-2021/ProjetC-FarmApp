#include <gtk/gtk.h>


void
on_connecter_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler2_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_4_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_aff_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok1_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok3_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok2_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler11_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_okk_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_controle_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_present_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourP_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_absente_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_activate                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_okmeilleur_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_meilleur_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_aaa_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_hemeee_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_capteur_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_troupaux_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_equipements_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestion_clients_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_calendar1_day_selected_double_click (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_Enregistrer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_oksave_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_historique_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rechercher2_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualier_historique_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_test_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview5_row_collapsed             (GtkTreeView     *treeview,
                                        GtkTreeIter     *iter,
                                        GtkTreePath     *path,
                                        gpointer         user_data);

void
on_treeview4_columns_changed           (GtkTreeView     *treeview,
                                        gpointer         user_data);

void
on_gestion_emplyer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_act_emploi_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_emploi_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton13_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton14_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ETUNDRE_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_calendar2_day_selected_double_click (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_calendar2_day_selected_double_click (GtkCalendar     *calendar,
                                        gpointer         user_data);
