

typedef struct 
{int jour;
int moin;
int anne;
}date;

typedef struct 
{char cinn[20];
char nomm[20];
char prenomm[20];
char emaill[20];
char postee[20];
char tell[20];
char salairee[20];
date dd;
int jt ;
int ja ;
char etat[20];

}employer;


employer o;
employer n;
enum
{
	ECIN,
	ENOM,
	EPRENOM,
	EEMAIL,
	ETEL,
	EPOSTE,
	ESALAIRE,
	ED,
	EJT,
	EJA,
	COLUMNS,
};
enum
{
	CIN,
	NOM,
	PRENOM,
	SALAIRE,
	JT,
	JA,
	RR,
	COLUMNS2,
};
enum
{
	CIN1,
	NOM1,
	PRENOM1,
	ETAT1,
	COLUMNS3,
};

enum
{
	DATE2,
	ETAT2,
	COLUMNS4,
};
enum
{
	ECINE,
	ENOME,
	LUNDI,
	MARDI,
	MERCREDI,
	JEUDI,
	VENDREDI,
	SAMEDI,
	DIMANCHE,
	COLUMNS5,
};
void supprimer_emploi(employer p1);
void modifier_emploi (employer a , employer o , int choix1[6]);
void afficher_emploi(GtkWidget *liste);
void emploi (int choix[6],employer p);
void historique_employer(GtkWidget *liste , char ch[20]);
void historique_date(GtkWidget *liste , char ch[20]);
void supprimer(employer p1);
void chercher(GtkWidget *liste , char ch[30]);
void afficher(GtkWidget *liste);
void afficher2(GtkWidget *liste);
void ajouter (employer p);
void modifier (employer p , employer o);
void absente (employer c);
void presente (employer c);
employer meilleur_employer();
void save(char x[30]);
void retour();
int verifier_enreg (char x[20]);
int verifier_cin (char ch[20]);
int verifier_salaire (char ch[20]);
int verifier_email (char ch[20]);
int verifier_lettre (char ch[20]);
int existe_employer (char y[20]);
