#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "employer.h"


void afficher(GtkWidget *liste)
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char prenom[30];
	char email[30];
	char poste[30];
	char tel[30];
	char salaire[30];
	int jtt;
	int jaa;
	int jj;
	int mm;
	int aa;char etat[20];
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20];
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECIN, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",EPRENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Email",renderer ,"text",EEMAIL, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Telephone",renderer ,"text",ETEL, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Poste",renderer ,"text",EPOSTE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("salaire",renderer ,"text",ESALAIRE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("D_recrutement",renderer ,"text",ED, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("J_travailles",renderer ,"text",EJT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("J_absentees",renderer ,"text",EJA, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("employer.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("employer.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",cin,nom,prenom,email,tel,poste,salaire,&jj,&mm,&aa,&jtt,&jaa,etat)!=EOF)
			{strcpy(d,"");
			sprintf(x,"%d",jtt);sprintf(y,"%d",jaa);
			sprintf(j,"%d",jj);sprintf(m,"%d",mm);sprintf(a,"%d",aa);
			strcat(d,j);strcat(d,"/");strcat(d,m);strcat(d,"/");strcat(d,a);
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECIN,cin,ENOM,nom,EPRENOM,prenom,EEMAIL,email,ETEL,tel,EPOSTE,poste,ESALAIRE,salaire,ED,d,EJT,x,EJA,y, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}



void chercher(GtkWidget *liste , char ch[30])
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char prenom[30];
	char email[30];
	char poste[30];
	char tel[30];
	char salaire[30];
	int jtt;
	int jaa;
	int jj;
	int mm;
	int aa;char etat[20];
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20];
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECIN, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",EPRENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Email",renderer ,"text",EEMAIL, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Telephone",renderer ,"text",ETEL, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Poste",renderer ,"text",EPOSTE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("salaire",renderer ,"text",ESALAIRE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("D_recrutement",renderer ,"text",ED, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("J_travailles",renderer ,"text",EJT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("J_absentees",renderer ,"text",EJA, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("employer.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("employer.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",cin,nom,prenom,email,tel,poste,salaire,&jj,&mm,&aa,&jtt,&jaa,etat)!=EOF)
			{if (strcmp(cin,ch)==0 || strcmp(nom,ch)==0){strcpy(d,"");
			sprintf(x,"%d",jtt);sprintf(y,"%d",jaa);
			sprintf(j,"%d",jj);sprintf(m,"%d",mm);sprintf(a,"%d",aa);
			strcat(d,j);strcat(d,"/");strcat(d,m);strcat(d,"/");strcat(d,a);
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECIN,cin,ENOM,nom,EPRENOM,prenom,EEMAIL,email,ETEL,tel,EPOSTE,poste,ESALAIRE,salaire,ED,d,EJT,x,EJA,y, -1);
			}}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}

void supprimer(employer p1)
{
FILE *f;
FILE *f1;

	    employer p;
	   
f=fopen("employer.txt","r");
f1=fopen("ancien.txt","w+");
if(f==NULL,f1==NULL)
 {
     return;
}else
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
{
if(strcmp(p1.cinn,p.cinn)!=0)
fprintf(f1,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}
fclose(f);
fclose(f1);
remove("employer.txt");
rename("ancien.txt","employer.txt");
}

void supprimer_emploi(employer p1)
{
FILE *f;
FILE *f1;
int choix_m[]={0,0,0,0,0,0,0};
employer p;
	   
f=fopen("emploi.txt","r");
f1=fopen("ancien1.txt","w+");
if(f==NULL,f1==NULL)
 {
     return;
}else
while(fscanf(f,"%s %s %d %d %d %d %d %d %d \n",p.cinn,p.nomm,&choix_m[0],&choix_m[1],&choix_m[2],&choix_m[3],&choix_m[4],&choix_m[5],&choix_m[6])!=EOF)
{
if(strcmp(p1.cinn,p.cinn)!=0)
fprintf(f1,"%s %s %d %d %d %d %d %d %d \n",p.cinn,p.nomm,choix_m[0],choix_m[1],choix_m[2],choix_m[3],choix_m[4],choix_m[5],choix_m[6]);
}
fclose(f);
fclose(f1);
remove("emploi.txt");
rename("ancien1.txt","emploi.txt");
}

void ajouter (employer p)
{
FILE *f=NULL;
f=fopen("employer.txt","a");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
fclose(f);

}
else
printf("\n Not found");


}


void emploi (int choix[6],employer p)
{
char b[20]="";
FILE *a=NULL;
a=fopen("emploi.txt","a");
strcat(b,p.nomm);strcat(b,"_");strcat(b,p.prenomm);
fprintf(a,"%s %s %d %d %d %d %d %d %d \n",p.cinn,b,choix[0],choix[1],choix[2],choix[3],choix[4],choix[5],choix[6]);
fclose(a);

}

void modifier (employer a , employer o)
{
employer p;
FILE *f;
FILE *g;


f=fopen("employer.txt","r");

g=fopen("neww.txt","w");


      while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {
	if(strcmp(o.cinn,p.cinn)==0)
		{
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",a.cinn,a.nomm,a.prenomm,a.emaill,a.tell,a.postee,p.salairee,a.dd.jour,a.dd.moin,a.dd.anne,p.jt,p.ja,p.etat);
		}
else
{fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}


}

fclose(f);
fclose(g);
remove("employer.txt");
rename("neww.txt","employer.txt");
}
void modifier_emploi (employer a , employer o , int choix1[6])
{
employer p;
FILE *f;
FILE *g;
int choix_m[]={0,0,0,0,0,0,0};

f=fopen("emploi.txt","r");

g=fopen("neww1.txt","w");


      while(fscanf(f,"%s %s %d %d %d %d %d %d %d \n",p.cinn,p.nomm,&choix_m[0],&choix_m[1],&choix_m[2],&choix_m[3],&choix_m[4],&choix_m[5],&choix_m[6])!=EOF){
    
	if(strcmp(o.cinn,p.cinn)==0)
		{
fprintf(g,"%s %s %d %d %d %d %d %d %d \n",a.cinn,a.nomm,choix1[0],choix1[1],choix1[2],choix1[3],choix1[4],choix1[5],choix1[6]);
		}
else
{fprintf(g,"%s %s %d %d %d %d %d %d %d \n",p.cinn,p.nomm,choix_m[0],choix_m[1],choix_m[2],choix_m[3],choix_m[4],choix_m[5],choix_m[6]);
}


}

fclose(f);
fclose(g);
remove("emploi.txt");
rename("neww1.txt","emploi.txt");
}

void presente (employer c)
{
employer p;

FILE *f;
FILE *g;


f=fopen("employer.txt","r");

g=fopen("neww.txt","w");


      while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {
	if(strcmp(c.cinn,p.cinn)==0)
		{p.jt=p.jt+1;strcpy(p.etat,"present");
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}
else
{fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}


}

fclose(f);
fclose(g);
remove("employer.txt");
rename("neww.txt","employer.txt");
}


void absente (employer c)
{
employer p;

FILE *f;
FILE *g;


f=fopen("employer.txt","r");

g=fopen("neww.txt","w");


      while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {
	if(strcmp(c.cinn,p.cinn)==0)
		{p.ja=p.ja+1;
		strcpy(p.etat,"absent");
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}
else
{fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);
}


}

fclose(f);
fclose(g);
remove("employer.txt");
rename("neww.txt","employer.txt");
}











void afficher2(GtkWidget *liste)
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char prenom[30];
	char email[30];
	char poste[30];
	char tel[30];
	char salaire[30];
	int jtt;
	int jaa;
	int jj;
	int mm;
	int aa;
	char etat[20];
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20];
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",CIN, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",NOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",PRENOM, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("salaire",renderer ,"text",SALAIRE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	    column = gtk_tree_view_column_new_with_attributes("J_travailles",renderer ,"text",JT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("J_absentees",renderer ,"text",JA, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Remarque",renderer ,"text",RR, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    }
	    store=gtk_list_store_new (COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("employer.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("employer.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",cin,nom,prenom,email,tel,poste,salaire,&jj,&mm,&aa,&jtt,&jaa,etat)!=EOF)
			{strcpy(d,"");
			sprintf(x,"%d",jtt);sprintf(y,"%d",jaa);
			sprintf(j,"%d",jj);sprintf(m,"%d",mm);sprintf(a,"%d",aa);
			strcat(d,j);strcat(d,"/");strcat(d,m);strcat(d,"/");strcat(d,a);
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,CIN,cin,NOM,nom,PRENOM,prenom,SALAIRE,salaire,JT,x,JA,y,RR,etat, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}



employer meilleur_employer()

{
employer p;
employer m;
int xx=0; 
FILE *f;



f=fopen("employer.txt","r");


  while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    { if (xx < p.jt) { m=p; xx = p.jt; } }
return m;

}



void save(char x[30])
{employer p;
FILE *f=NULL;
f=fopen("employer.txt","r");
FILE *d=NULL;
d=fopen("save.txt","a+");

 while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {
fprintf(d,"%s %s %s %s %s %s %s %s %d %d %d %d %d %s\n",x,p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);

}fclose(f);
fclose(d);
}
void retour()
{
employer p;

FILE *f;
FILE *g;


f=fopen("employer.txt","r");

g=fopen("neww.txt","w+");
if(f!=NULL)
{
 while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {strcpy(p.etat,"....");
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,p.dd.jour,p.dd.moin,p.dd.anne,p.jt,p.ja,p.etat);

}}
fclose(f);
fclose(g);
remove("employer.txt");
rename("neww.txt","employer.txt");

}

int verifier_enreg (char x[20])
{employer p;
char y[20];
int z=0;
FILE *d=NULL;
d=fopen("save.txt","a+");

 while(fscanf(d,"%s %s %s %s %s %s %s %s %d %d %d %d %d %s\n",y,p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    {if(strcmp(x,y)==0)
	z = z+1;
	}
fclose(d);
if (z>0)
return 1;
else 
return 0;
}






void historique_date(GtkWidget *liste , char ch[20])
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char prenom[30];
	char email[30];
	char poste[30];
	char tel[30];
	char salaire[30];
	int jtt;
	int jaa;
	int jj;
	int mm;
	int aa;char etat[20];
	char date[20];

	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",CIN1, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",NOM1, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",PRENOM1, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Remarque",renderer ,"text",ETAT1, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	}
	    store=gtk_list_store_new (COLUMNS3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("save.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("save.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d %d %d %s\n",date,cin,nom,prenom,email,tel,poste,salaire,&jj,&mm,&aa,&jtt,&jaa,etat)!=EOF)
			{ if (strcmp(ch,date)==0)
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,CIN1,cin,NOM1,nom,PRENOM1,prenom,ETAT1,etat, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}


void historique_employer(GtkWidget *liste , char ch[20])
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char prenom[30];
	char email[30];
	char poste[30];
	char tel[30];
	char salaire[30];
	int jtt;
	int jaa;
	int jj;
	int mm;
	int aa;char etat[20];
	char date[20];

	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Date    ",renderer ,"text",DATE2, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	   
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Remarque    ",renderer ,"text",ETAT2, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	}
	    store=gtk_list_store_new (COLUMNS4, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("save.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("save.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d %d %d %s\n",date,cin,nom,prenom,email,tel,poste,salaire,&jj,&mm,&aa,&jtt,&jaa,etat)!=EOF)
			{ if (strcmp(ch,cin)==0)
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,DATE2,date,ETAT2,etat, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}

int existe_employer (char y[20])
{
employer p; FILE *f;
int x = 0;
f=fopen("employer.txt","r");

if(f!=NULL)
{
 while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %s\n",p.cinn,p.nomm,p.prenomm,p.emaill,p.tell,p.postee,p.salairee,&p.dd.jour,&p.dd.moin,&p.dd.anne,&p.jt,&p.ja,p.etat)!=EOF)
    { if (strcmp(p.cinn,y)==0)
	x = 1; }
}
 if ( x == 1 ) return 0;
    else return 1;
}



int verifier_cin (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != '0' && ch[i] != '1' && ch[i] != '2' && ch[i] != '3' &&ch[i] != '4' &&ch[i] != '5' &&ch[i] != '6' &&ch[i] != '7' &&ch[i] != '8' &&ch[i] != '9'  || strlen(ch)!=8 )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}
int verifier_salaire (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != '0' && ch[i] != '1' && ch[i] != '2' && ch[i] != '3' &&ch[i] != '4' &&ch[i] != '5' &&ch[i] != '6' &&ch[i] != '7' &&ch[i] != '8' &&ch[i] != '9'   )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}
int verifier_email (char ch[20])
{int i;int x = 0;int y = 0; int z = 0; int b = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] == '@' )
    x =x+ 1 ;
    if (ch[i] == '.' )
    b =b+ 1 ;
    if (ch[i] == ' ' )
    y = 1 ;}
    if (ch [0]=='@' || ch[strlen(ch)-1]=='@' || ch[strlen(ch)-1]=='.' )
        z =1;
   if ( x == 1 && y == 0 && z == 0 && b >0) return 1;
    else return 0;
}
int verifier_lettre (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != 'a' && ch[i] != 'b' && ch[i] != 'c' && ch[i] != 'd' &&ch[i] != 'e' &&ch[i] != 'f' &&ch[i] != 'g' &&ch[i] != 'h' &&ch[i] != 'i' &&ch[i] != 'g' &&ch[i] != 'k'&&ch[i] != 'l'&&ch[i] != 'm'&&ch[i] != 'n'&&ch[i] != 'o'&&ch[i] != 'p'&&ch[i] != 'g'&&ch[i] != 'q'&&ch[i] != 'r'&&ch[i] != 's'&&ch[i] != 't'&&ch[i] != 'u'&&ch[i] != 'v'&&ch[i] != 'w'&&ch[i] != 'x'&&ch[i] != 'z'  )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}




void afficher_emploi(GtkWidget *liste)
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    employer p;
            char cin[30];
	char nom[30];
	char a1[4];char a2[4];char a3[4];char a4[4];char a5[4];char a6[4];char a7[4];
int choix_e[]={0,0,0,0,0,0,0};
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECINE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOME, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Lundi",renderer ,"text",LUNDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Mardi",renderer ,"text",MARDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Mercredi",renderer ,"text",MERCREDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Jeudi",renderer ,"text",JEUDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Vendredi",renderer ,"text",VENDREDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("samedi",renderer ,"text",SAMEDI, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Dimanche",renderer ,"text",DIMANCHE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    }
	    store=gtk_list_store_new (COLUMNS5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("emploi.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("emploi.txt","a+");
			while(fscanf(f,"%s %s %d %d %d %d %d %d %d \n",cin,nom,&choix_e[0],&choix_e[1],&choix_e[2],&choix_e[3],&choix_e[4],&choix_e[5],&choix_e[6])!=EOF)
			{if (choix_e[0] == 1) strcpy(a1,"oui"); else strcpy(a1,"non");
			if (choix_e[1] == 1) strcpy(a2,"oui"); else strcpy(a2,"non");
			if (choix_e[2] == 1) strcpy(a3,"oui"); else strcpy(a3,"non");
			if (choix_e[3] == 1) strcpy(a4,"oui"); else strcpy(a4,"non");
			if (choix_e[4] == 1) strcpy(a5,"oui"); else strcpy(a5,"non");
			if (choix_e[5] == 1) strcpy(a6,"oui"); else strcpy(a6,"non");
			if (choix_e[6] == 1) strcpy(a7,"oui"); else strcpy(a7,"non");

				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECINE,cin,ENOME,nom,LUNDI,a1,MARDI,a2,MERCREDI,a3,JEUDI,a4,VENDREDI,a5,SAMEDI,a6,DIMANCHE,a7, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}


