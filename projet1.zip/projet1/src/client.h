typedef struct 
{int journ;
int moinn;
int annen;
}date_n;

typedef struct 
{char cinlh[20];
char nomlh[20];
char prenomlh[20];
char emaillh[20];
char lieulh[20];
char tellh[20];

date_n dt;
}client;

typedef struct 
{char cinalh[20];
char nomalh[20];
char prenomalh[20];
int moutons ;
int vaches;
int poules;
int chevales;
int fruits;
int legumes;
int facture;

date_n da;
}commande;
enum
{
	ECINLH,
	ENOMLH,
	EPRENOMLH,
	EEMAILLH,
	ETELLH,
	ELIEULH,
	EDDN,
	COLUMNSL,
};
enum
{
	ECINOLH,
	ENOMOLH,
	EPRENOMOLH,
	EMLH,
	EVLH,
	EPLH,
	ECLH,
	EFLH,
	ELLH,
	ESSLH,
	EDDLH,
	COLUMNSL1,
};

client o;
client n;

commande meulleur_client();
void ajouter_commande (commande c);
void ajouter_client (client c);
void modifier_client (client a , client o);
void afficher_client(GtkWidget *liste);
void supprimer_client(client p1);
void chercher_client(GtkWidget *liste,char ch[30]);
void historique_commande(GtkWidget *liste);
int existe_employer (char y[20]);
int verifier_lettre (char ch[20]);
int verifier_email (char ch[20]);
int verifier_salaire (char ch[20]);
int verifier_cin (char ch[20]);
