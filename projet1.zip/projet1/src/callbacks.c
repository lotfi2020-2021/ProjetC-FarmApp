#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "client.h"

void
on_ajouter_lotfi_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aceuile_lotfi;
aceuile_lotfi=lookup_widget(button,"aceuile_lotfi");
gtk_widget_destroy(aceuile_lotfi);
GtkWidget *ajouter_lotfi;
  ajouter_lotfi = create_ajouter_lotfi ();
  gtk_widget_show (ajouter_lotfi);
GtkWidget *labelnom_lotfi;
labelnom_lotfi = lookup_widget (ajouter_lotfi ,"labelnom_lotfi");
GtkWidget *labelcin_lotfi;
labelcin_lotfi = lookup_widget (ajouter_lotfi ,"labelcin_lotfi");
GtkWidget *labelprenom_lotfi;
labelprenom_lotfi = lookup_widget (ajouter_lotfi ,"labelprenom_lotfi");
GtkWidget *labeltel_lotfi;
labeltel_lotfi = lookup_widget (ajouter_lotfi ,"labeltel_lotfi");
GtkWidget *labelemail_lotfi;
labelemail_lotfi = lookup_widget (ajouter_lotfi ,"labelemail_lotfi");
GtkWidget *labellieux_lotfi;
labellieux_lotfi = lookup_widget (ajouter_lotfi ,"labellieux_lotfi");
GtkWidget *labelcinn_lotfi;
labelcinn_lotfi = lookup_widget (ajouter_lotfi ,"labelcinn_lotfi");
gtk_widget_hide(labelnom_lotfi);
gtk_widget_hide(labelcin_lotfi);
gtk_widget_hide(labelprenom_lotfi);
gtk_widget_hide(labeltel_lotfi);
gtk_widget_hide(labellieux_lotfi);
gtk_widget_hide(labelemail_lotfi);
gtk_widget_hide(labelcinn_lotfi);
}


void
on_supprimer_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *confurmer_lotfi;
confurmer_lotfi = create_confurmer_lotfi ();
  gtk_widget_show (confurmer_lotfi);
}


void
on_modifier_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aceuile_lotfi;
aceuile_lotfi=lookup_widget(button,"aceuile_lotfi");
gtk_widget_destroy(aceuile_lotfi);
client c;
FILE *f;
f=fopen("client.txt","r");
GtkWidget *modifier_lotfi;
  modifier_lotfi = create_modifier_lotfi ();
  gtk_widget_show (modifier_lotfi);
GtkWidget *labelnom_lotfi;
labelnom_lotfi = lookup_widget (modifier_lotfi ,"labelnom11_lotfi");
GtkWidget *labelcin_lotfi;
labelcin_lotfi = lookup_widget (modifier_lotfi ,"labelcin1_lotfi");
GtkWidget *labelprenom_lotfi;
labelprenom_lotfi = lookup_widget (modifier_lotfi ,"labelprenom1_lotfi");
GtkWidget *labeltel_lotfi;
labeltel_lotfi = lookup_widget (modifier_lotfi ,"labeltel1_lotfi");
GtkWidget *labelemail_lotfi;
labelemail_lotfi = lookup_widget (modifier_lotfi ,"labelemail1_lotfi");
GtkWidget *labellieux_lotfi;
labellieux_lotfi = lookup_widget (modifier_lotfi ,"labellieu1_lotfi");
GtkWidget *labelcinn_lotfi;
labelcinn_lotfi = lookup_widget (modifier_lotfi ,"labelcinn1_lotfi");
gtk_widget_hide(labelnom_lotfi);
gtk_widget_hide(labelcin_lotfi);
gtk_widget_hide(labelprenom_lotfi);
gtk_widget_hide(labeltel_lotfi);
gtk_widget_hide(labellieux_lotfi);
gtk_widget_hide(labelemail_lotfi);
gtk_widget_hide(labelcinn_lotfi);
while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,&c.dt.journ,&c.dt.moinn,&c.dt.annen)!=EOF)
{ if (strcmp(c.cinlh,o.cinlh)==0){
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifier_lotfi,"cin1_lotfi")),c.cinlh);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifier_lotfi,"nom1_lotfi")),c.nomlh);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifier_lotfi,"prenom1_lotfi")),c.prenomlh);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifier_lotfi,"email1_lotfi")),c.emaillh);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifier_lotfi,"tel1_lotfi")),c.tellh);
		//gtk_entry_set_text(GTK_ENTRY(lookup_widget(wmodifier,"salaire1")),c.lieulh);
}}
}


void
on_actualiser_lotfi_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1_lotfi;
GtkWidget *aceuile_lotfi;
aceuile_lotfi=lookup_widget(button,"aceuile_lotfi");

treeview1_lotfi=lookup_widget(aceuile_lotfi,"treeview1_lotfi");
afficher_client(treeview1_lotfi);
}


void
on_ajouter1_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *finajouter;

GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *cin;
GtkWidget *email;
GtkWidget *tel;
GtkWidget *lieux;
GtkWidget *mm;
GtkWidget *aa;
GtkWidget *jj;



client p;



nom = lookup_widget (button ,"nom_lotfi");
prenom = lookup_widget (button ,"prenom_lotfi");
cin = lookup_widget (button ,"cin_lotfi");
email = lookup_widget (button ,"email_lotfi");
tel = lookup_widget (button ,"tel_lotfi");
lieux = lookup_widget (button ,"comboboxentry1_lotfi");
jj = lookup_widget (button ,"spinbutton1_lotfi");
mm = lookup_widget (button ,"spinbutton2_lotfi");
aa = lookup_widget (button ,"spinbutton3_lotfi");


p.dt.journ=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.dt.moinn=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.dt.annen=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));

strcpy(p.nomlh, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(p.prenomlh, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(p.emaillh, gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(p.lieulh, gtk_combo_box_get_active_text(GTK_COMBO_BOX(lieux)));
strcpy(p.cinlh, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(p.tellh, gtk_entry_get_text(GTK_ENTRY(tel)));

int b =0;

GtkWidget *labelnom_lotfi;
labelnom_lotfi = lookup_widget (button ,"labelnom_lotfi");
GtkWidget *labelcin_lotfi;
labelcin_lotfi = lookup_widget (button ,"labelcin_lotfi");
GtkWidget *labelprenom_lotfi;
labelprenom_lotfi = lookup_widget (button ,"labelprenom_lotfi");
GtkWidget *labeltel_lotfi;
labeltel_lotfi = lookup_widget (button ,"labeltel_lotfi");
GtkWidget *labelemail_lotfi;
labelemail_lotfi = lookup_widget (button ,"labelemail_lotfi");
GtkWidget *labellieux_lotfi;
labellieux_lotfi = lookup_widget (button ,"labellieux_lotfi");
GtkWidget *labelcinn_lotfi;
labelcinn_lotfi = lookup_widget (button ,"labelcinn_lotfi");

/*if (existe_employer (p.cinlh)==0 ){b=1;
	          gtk_widget_show (labelcin_lotfi);
}
else {
		  gtk_widget_hide(labelcin_lotfi);
}*/
if (verifier_cin (p.cinlh)==0 || (strcmp(p.cinlh,"")==0)){b=1;
	          gtk_widget_show (labelcinn_lotfi);
}
else {
		  gtk_widget_hide(labelcinn_lotfi);
}
if (verifier_cin (p.tellh)==0 || (strcmp(p.tellh,"")==0)){b=1;
	          gtk_widget_show (labeltel_lotfi);

}
else {
		  gtk_widget_hide(labeltel_lotfi);
}	

if (verifier_email (p.emaillh)==0 || (strcmp(p.emaillh,"")==0) ){b=1;
	gtk_widget_show (labelemail_lotfi);

}
else {
		  gtk_widget_hide(labelemail_lotfi);
}
if (verifier_lettre (p.nomlh)==0 || (strcmp(p.nomlh,"")==0) ){b=1;
	gtk_widget_show (labelnom_lotfi);

}
else {
		  gtk_widget_hide(labelnom_lotfi);
}
if (verifier_lettre (p.prenomlh)==0 || (strcmp(p.prenomlh,"")==0) ){b=1;
	gtk_widget_show (labelprenom_lotfi);

}
else {
		  gtk_widget_hide(labelprenom_lotfi);
}
if(strcmp(p.lieulh,"")==0){b=1;
	gtk_widget_show (labellieux_lotfi);

}
else {
		  gtk_widget_hide(labellieux_lotfi);
}	  
if (b == 0){
ajouter_client(p);
}

}


void
on_annuler1_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajoutclient;
windowajoutclient=lookup_widget(button,"ajouter_lotfi");
gtk_widget_destroy(windowajoutclient);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);



GtkWidget *treeview3_lotfi;
treeview3_lotfi=lookup_widget(acceuil,"treeview3_lotfi");
historique_commande(treeview3_lotfi);

GtkWidget *treeview2_lotfi;
treeview2_lotfi=lookup_widget(acceuil,"treeview2_lotfi");
afficher_client(treeview2_lotfi);

GtkWidget *treeview1_lotfi;
treeview1_lotfi=lookup_widget(acceuil,"treeview1_lotfi");
afficher_client(treeview1_lotfi);
}


void
on_modifier1_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *finajouter;

GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *cin;
GtkWidget *email;
GtkWidget *tel;
GtkWidget *lieux;
GtkWidget *mm;
GtkWidget *aa;
GtkWidget *jj;



client p;



nom = lookup_widget (button ,"nom1_lotfi");
prenom = lookup_widget (button ,"prenom1_lotfi");
cin = lookup_widget (button ,"cin1_lotfi");
email = lookup_widget (button ,"email1_lotfi");
tel = lookup_widget (button ,"tel1_lotfi");
lieux = lookup_widget (button ,"comboboxentry2_lotfi");
jj = lookup_widget (button ,"spinbutton4_lotfi");
mm = lookup_widget (button ,"spinbutton5_lotfi");
aa = lookup_widget (button ,"spinbutton6_lotfi");


p.dt.journ=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.dt.moinn=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.dt.annen=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));

strcpy(p.nomlh, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(p.prenomlh, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(p.emaillh, gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(p.lieulh, gtk_combo_box_get_active_text(GTK_COMBO_BOX(lieux)));
strcpy(p.cinlh, gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(p.tellh, gtk_entry_get_text(GTK_ENTRY(tel)));


int b =0;

GtkWidget *labelnom_lotfi;
labelnom_lotfi = lookup_widget (button ,"labelnom11_lotfi");
GtkWidget *labelcin_lotfi;
labelcin_lotfi = lookup_widget (button ,"labelcin1_lotfi");
GtkWidget *labelprenom_lotfi;
labelprenom_lotfi = lookup_widget (button ,"labelprenom1_lotfi");
GtkWidget *labeltel_lotfi;
labeltel_lotfi = lookup_widget (button ,"labeltel1_lotfi");
GtkWidget *labelemail_lotfi;
labelemail_lotfi = lookup_widget (button ,"labelemail1_lotfi");
GtkWidget *labellieux_lotfi;
labellieux_lotfi = lookup_widget (button ,"labellieu1_lotfi");
GtkWidget *labelcinn_lotfi;
labelcinn_lotfi = lookup_widget (button ,"labelcinn1_lotfi");

/*if (existe_employer (p.cinlh)==0 ){b=1;
	          gtk_widget_show (labelcin_lotfi);
}
else {
		  gtk_widget_hide(labelcin_lotfi);
}*/
if (verifier_cin (p.cinlh)==0 || (strcmp(p.cinlh,"")==0)){b=1;
	          gtk_widget_show (labelcinn_lotfi);
}
else {
		  gtk_widget_hide(labelcinn_lotfi);
}
if (verifier_cin (p.tellh)==0 || (strcmp(p.tellh,"")==0)){b=1;
	          gtk_widget_show (labeltel_lotfi);

}
else {
		  gtk_widget_hide(labeltel_lotfi);
}	

if (verifier_email (p.emaillh)==0 || (strcmp(p.emaillh,"")==0) ){b=1;
	gtk_widget_show (labelemail_lotfi);

}
else {
		  gtk_widget_hide(labelemail_lotfi);
}
if (verifier_lettre (p.nomlh)==0 || (strcmp(p.nomlh,"")==0) ){b=1;
	gtk_widget_show (labelnom_lotfi);

}
else {
		  gtk_widget_hide(labelnom_lotfi);
}
if (verifier_lettre (p.prenomlh)==0 || (strcmp(p.prenomlh,"")==0) ){b=1;
	gtk_widget_show (labelprenom_lotfi);

}
else {
		  gtk_widget_hide(labelprenom_lotfi);
}
if(strcmp(p.lieulh,"")==0){b=1;
	gtk_widget_show (labellieux_lotfi);

}
else {
		  gtk_widget_hide(labellieux_lotfi);
}	  
if (b == 0){
modifier_client (p,o);}
GtkWidget *modifierclient;
modifierclient=lookup_widget(button,"modifier_lotfi");
gtk_widget_destroy(modifierclient);
GtkWidget *modificationsucee;
modificationsucee = create_windowmodificationsucee_lotfi();
gtk_widget_show (modificationsucee);
}


void
on_annuler2_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *windowmodifierclient;
windowmodifierclient=lookup_widget(button,"modifier_lotfi");
gtk_widget_destroy(windowmodifierclient);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);

GtkWidget *treeview3_lotfi;
treeview3_lotfi=lookup_widget(acceuil,"treeview3_lotfi");
historique_commande(treeview3_lotfi);

GtkWidget *treeview2_lotfi;
treeview2_lotfi=lookup_widget(acceuil,"treeview2_lotfi");
afficher_client(treeview2_lotfi);

GtkWidget *treeview1_lotfi;
treeview1_lotfi=lookup_widget(acceuil,"treeview1_lotfi");
afficher_client(treeview1_lotfi);
}


void
on_treeview1_lotfi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* email;
	gchar* tel;
	gchar* cin;
	gchar* lieu;
	gchar* date;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &cin, 1, &nom,2,&prenom,3,&email,4,&tel,5,&lieu,6,&date,-1);
	strcpy(o.cinlh,cin);  
	
	}
}


void
on_annule_confirmer_lotfi_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"confurmer_lotfi");
gtk_widget_destroy(confirmesupprimer);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);
}


void
on_confirmer_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_client(o);
GtkWidget *confirmesupprimer;
confirmesupprimer=lookup_widget(button,"confurmer_lotfi");
gtk_widget_destroy(confirmesupprimer);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);
}


void
on_recherch_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cherch;
char ch[20];
GtkWidget *treeview1_lotfi;
GtkWidget *aceuile_lotfi;
aceuile_lotfi=lookup_widget(button,"aceuile_lotfi");

treeview1_lotfi=lookup_widget(aceuile_lotfi,"treeview1_lotfi");
cherch = lookup_widget (button ,"rechercher_lotfi");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(cherch)));
 chercher_client(treeview1_lotfi,ch);

}


void
on_treeview2_lotfi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* email;
	gchar* tel;
	gchar* cin;
	gchar* lieu;
	gchar* date;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &cin, 1, &nom,2,&prenom,3,&email,4,&tel,5,&lieu,6,&date,-1);
	strcpy(o.cinlh,cin);  
	strcpy(o.nomlh,nom); 
	strcpy(o.prenomlh,prenom); 
	}
}


void
on_act_achat_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2_lotfi;
GtkWidget *aceuile_lotfi;
aceuile_lotfi=lookup_widget(button,"aceuile_lotfi");

treeview2_lotfi=lookup_widget(aceuile_lotfi,"treeview2_lotfi");
afficher_client(treeview2_lotfi);
}


void
on_con_achat_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *cin;
GtkWidget *m;
GtkWidget *v;
GtkWidget *po;
GtkWidget *c;
GtkWidget *f;
GtkWidget *l;
GtkWidget *mm;
GtkWidget *aa;
GtkWidget *jj;



commande p;

GtkWidget *calendar;
calendar=lookup_widget(button,"calendar1_lotfi");
gtk_calendar_get_date (GTK_CALENDAR(calendar),
                       &p.da.annen,
                       &p.da.moinn,
                       &p.da.journ);

m = lookup_widget (button ,"spinbutton10_lotfi");
v = lookup_widget (button ,"spinbutton20_lotfi");
po = lookup_widget (button ,"spinbutton30_lotfi");
c = lookup_widget (button ,"spinbutton40_lotfi");
f = lookup_widget (button ,"spinbutton50_lotfi");
l = lookup_widget (button ,"spinbutton60_lotfi");
jj = lookup_widget (button ,"spinbutton70_lotfi");
mm = lookup_widget (button ,"spinbutton80_lotfi");
aa = lookup_widget (button ,"spinbutton90_lotfi");

p.moutons=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
p.vaches=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(v));
p.poules=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(po));
p.chevales=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(c));
p.fruits=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(f));
p.legumes=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(l));

/*p.da.journ=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
p.da.moinn=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
p.da.annen=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aa));*/
p.da.moinn=p.da.moinn+1;

strcpy(p.cinalh,o.cinlh);
strcpy(p.nomalh,o.nomlh);
strcpy(p.prenomalh,o.prenomlh);
p.facture = p.moutons * 500 + p.vaches* 2000 + p.poules * 20 + p.chevales * 5000 + p.fruits * 20 + p.legumes * 30 ;
char aaa[10]="";
sprintf(aaa,"%d",p.facture);
GtkWidget *total_lotfi;
total_lotfi = lookup_widget (button ,"total_lotfi");
GtkWidget *label_enr_lotfi;
label_enr_lotfi = lookup_widget (button ,"label_enr_lotfi");

ajouter_commande ( p);
gtk_label_set_text(GTK_LABEL(label_enr_lotfi),"commande enregistreé");
gtk_label_set_text(GTK_LABEL(total_lotfi),aaa);
}


void
on_act_h_lotfi_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview3_lotfi;
GtkWidget *aceuile_lotfi;
treeview3_lotfi=lookup_widget(button,"treeview3_lotfi");
historique_commande(treeview3_lotfi);
}


void
on_meilleur_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *meulleur_lotfi;
meulleur_lotfi = create_meulleur_lotfi ();
  gtk_widget_show (meulleur_lotfi);
}


void
on_act_meulleur_lotfi_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
commande t;
t =  meulleur_client();
char x[10]="";
sprintf(x,"%d",t.facture);
strcat(t.nomalh," ");strcat(t.nomalh,t.prenomalh);strcat(t.nomalh," : ");strcat(t.nomalh,x);strcat(t.nomalh," dt ");
GtkWidget* labelmm_motfi;

labelmm_motfi = lookup_widget(button, "labelmm_motfi") ;

gtk_label_set_text(GTK_LABEL(labelmm_motfi),t.nomalh);
}


void
on_buttonlogin_lotfi_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *login, *mdp ;
char user[20];
char pasw[20];
char user1[20];
char pasw1[20];
int trouve;
login=lookup_widget (button,"entryuser_lotfi");
mdp=lookup_widget (button,"entrypsw_lotfi");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(mdp)));
FILE *f;
f=fopen("user.txt","r");
while(fscanf(f,"%s %s \n",user1,pasw1)!=EOF){
if((strcmp(user,user1)==0)&&(strcmp(pasw,pasw1)==0))
{
GtkWidget *authentification;
authentification=lookup_widget(button,"windowadmin_lotfi");
gtk_widget_destroy(authentification);
GtkWidget *gestion;
gestion = create_windowgestion_lotfi();
gtk_widget_show (gestion);
}
}}

void
on_buttonclient_lotfi_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *gestion;
gestion=lookup_widget(button,"windowgestion_lotfi");
gtk_widget_destroy(gestion);

GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);

GtkWidget *treeview3_lotfi;
treeview3_lotfi=lookup_widget(acceuil,"treeview3_lotfi");
historique_commande(treeview3_lotfi);

GtkWidget *treeview2_lotfi;
treeview2_lotfi=lookup_widget(acceuil,"treeview2_lotfi");
afficher_client(treeview2_lotfi);

GtkWidget *treeview1_lotfi;
treeview1_lotfi=lookup_widget(acceuil,"treeview1_lotfi");
afficher_client(treeview1_lotfi);

}


void
on_buttonokajout_lotfi_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajoutsuccee;
ajoutsuccee=lookup_widget(button,"windowajoutsuccee_lotfi");
gtk_widget_destroy(ajoutsuccee);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);



GtkWidget *treeview3_lotfi;
treeview3_lotfi=lookup_widget(acceuil,"treeview3_lotfi");
historique_commande(treeview3_lotfi);

GtkWidget *treeview2_lotfi;
treeview2_lotfi=lookup_widget(acceuil,"treeview2_lotfi");
afficher_client(treeview2_lotfi);

GtkWidget *treeview1_lotfi;
treeview1_lotfi=lookup_widget(acceuil,"treeview1_lotfi");
afficher_client(treeview1_lotfi);
}


void
on_buttonokmodifier_lotfi_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifiersuccee;
modifiersuccee=lookup_widget(button,"windowmodificationsucee_lotfi");
gtk_widget_destroy(modifiersuccee);
GtkWidget *acceuil;
acceuil = create_aceuile_lotfi();
gtk_widget_show (acceuil);




GtkWidget *treeview3_lotfi;
treeview3_lotfi=lookup_widget(acceuil,"treeview3_lotfi");
historique_commande(treeview3_lotfi);

GtkWidget *treeview2_lotfi;
treeview2_lotfi=lookup_widget(acceuil,"treeview2_lotfi");
afficher_client(treeview2_lotfi);

GtkWidget *treeview1_lotfi;
treeview1_lotfi=lookup_widget(acceuil,"treeview1_lotfi");
afficher_client(treeview1_lotfi);
}

