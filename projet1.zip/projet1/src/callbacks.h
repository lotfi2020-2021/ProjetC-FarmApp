#include <gtk/gtk.h>


void
on_ajouter_lotfi_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_lotfi_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter1_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler1_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier1_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler2_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_lotfi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_annule_confirmer_lotfi_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherch_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_lotfi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_act_achat_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_con_achat_lotfi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_h_lotfi_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_meilleur_lotfi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_meulleur_lotfi_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonlogin_lotfi_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonclient_lotfi_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonokajout_lotfi_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonokmodifier_lotfi_clicked      (GtkButton       *button,
                                        gpointer         user_data);
