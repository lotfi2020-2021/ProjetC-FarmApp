#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"




void ajouter_client (client c)
{
FILE *f=NULL;
f=fopen("client.txt","a");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,c.dt.journ,c.dt.moinn,c.dt.annen);
fclose(f);

}
else
printf("\n Not found");


}

void modifier_client (client a , client o)
{
client c;
FILE *f;
FILE *g;


f=fopen("client.txt","r");

g=fopen("newl.txt","w");


      while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,&c.dt.journ,&c.dt.moinn,&c.dt.annen)!=EOF)
    {
	if(strcmp(o.cinlh,c.cinlh)==0)
		{
fprintf(g,"%s %s %s %s %s %s %d %d %d  \n",a.cinlh,a.nomlh,a.prenomlh,a.tellh,a.emaillh,a.lieulh,a.dt.journ,a.dt.moinn,a.dt.annen);
		}
else
{fprintf(g,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,c.dt.journ,c.dt.moinn,c.dt.annen);
}


}

fclose(f);
fclose(g);
remove("client.txt");
rename("newl.txt","client.txt");
}



void supprimer_client(client p1)
{
FILE *f;
FILE *f1;

	    client c;
	   
f=fopen("client.txt","r");
f1=fopen("ancienl.txt","w+");
if(f==NULL,f1==NULL)
 {
     return;
}else
while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,&c.dt.journ,&c.dt.moinn,&c.dt.annen)!=EOF)
{
if(strcmp(p1.cinlh,c.cinlh)!=0)
fprintf(f1,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,c.dt.journ,c.dt.moinn,c.dt.annen);
}
fclose(f);
fclose(f1);
remove("client.txt");
rename("ancienl.txt","client.txt");
}











void afficher_client(GtkWidget *liste)
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    
       client c;
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20];
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECINLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOMLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",EPRENOMLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Email",renderer ,"text",EEMAILLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Telephone",renderer ,"text",ETELLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Lieux",renderer ,"text",ELIEULH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Date NAISSANCE",renderer ,"text",EDDN, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	    
	    }
	    store=gtk_list_store_new (COLUMNSL, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("client.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("client.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,&c.dt.journ,&c.dt.moinn,&c.dt.annen)!=EOF)
			{strcpy(d,"");
			sprintf(j,"%d",c.dt.journ);sprintf(m,"%d",c.dt.moinn);sprintf(a,"%d",c.dt.annen);
			strcat(d,j);strcat(d,"/");strcat(d,m);strcat(d,"/");strcat(d,a);
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECINLH,c.cinlh,ENOMLH,c.nomlh,EPRENOMLH,c.prenomlh,EEMAILLH,c.emaillh,ETELLH,c.tellh,ELIEULH,c.lieulh,EDDN,d, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}





void chercher_client(GtkWidget *liste,char ch[30])
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    
       client c;
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20];
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECINLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOMLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",EPRENOMLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Email",renderer ,"text",EEMAILLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Telephone",renderer ,"text",ETELLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Lieux",renderer ,"text",ELIEULH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Date NAISSANCE",renderer ,"text",EDDN, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	    
	    }
	    store=gtk_list_store_new (COLUMNSL, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("client.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("client.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",c.cinlh,c.nomlh,c.prenomlh,c.tellh,c.emaillh,c.lieulh,&c.dt.journ,&c.dt.moinn,&c.dt.annen)!=EOF)
			{if (strcmp(c.cinlh,ch)==0){strcpy(d,"");
			sprintf(j,"%d",c.dt.journ);sprintf(m,"%d",c.dt.moinn);sprintf(a,"%d",c.dt.annen);
			strcat(d,j);strcat(d,"/");strcat(d,m);strcat(d,"/");strcat(d,a);
				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECINLH,c.cinlh,ENOMLH,c.nomlh,EPRENOMLH,c.prenomlh,EEMAILLH,c.emaillh,ETELLH,c.tellh,ELIEULH,c.lieulh,EDDN,d, -1);
			}}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}


void ajouter_commande (commande c)
{
FILE *f=NULL;
f=fopen("commande.txt","a");
if(f!=NULL)
{
fprintf(f,"%s %s %s %d %d %d %d %d %d %d %d %d %d \n",c.cinalh,c.nomalh,c.prenomalh,c.moutons,c.vaches,c.poules,c.chevales,c.fruits,c.legumes,c.da.journ,c.da.moinn,c.da.annen,c.facture);
fclose(f);

}
else
printf("\n Not found");


}



void historique_commande(GtkWidget *liste)
{
            GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    
       commande c;
char x1[20];char x2[20];char x3[20];char x4[20];char x5[20];char x6[20];char x7[20];
char cin[20];char nom[20];char prenom[20];
char a1[20];char a2[20];char a3[20];
char x[30];char y[30];
char j[30];char m[30];char a[30];char d[20]="";
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("CIN",renderer ,"text",ECINOLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nom",renderer ,"text",ENOMOLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer ,"text",EPRENOMOLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb moutons",renderer ,"text",EMLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb vaches",renderer ,"text",EVLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb poules",renderer ,"text",EPLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb chevales",renderer ,"text",ECLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb fruis",renderer ,"text",EFLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Nb legumes",renderer ,"text",ELLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("D.commande",renderer ,"text",ESSLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Prix",renderer ,"text",EDDLH, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	    
	    }
	    store=gtk_list_store_new (COLUMNSL1, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	    f=fopen("commande.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("commande.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",cin,nom,prenom,x1,x2,x3,x4,x5,x6,a1,a2,a3,x7)!=EOF)
			{strcpy(d,"");
			
			strcat(d,a1);strcat(d,"/");strcat(d,a2);strcat(d,"/");strcat(d,a3);



				gtk_list_store_append (store, &iter);
				gtk_list_store_set(store,&iter,ECINOLH,cin,ENOMOLH,nom,EPRENOMOLH,prenom,EMLH,x1,EVLH,x2,EPLH,x3,ECLH,x4,EFLH,x5,ELLH,x6,EDDLH,x7,ESSLH,d, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
}


int verifier_cin (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != '0' && ch[i] != '1' && ch[i] != '2' && ch[i] != '3' &&ch[i] != '4' &&ch[i] != '5' &&ch[i] != '6' &&ch[i] != '7' &&ch[i] != '8' &&ch[i] != '9'  || strlen(ch)!=8 )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}
int verifier_salaire (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != '0' && ch[i] != '1' && ch[i] != '2' && ch[i] != '3' &&ch[i] != '4' &&ch[i] != '5' &&ch[i] != '6' &&ch[i] != '7' &&ch[i] != '8' &&ch[i] != '9'   )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}
int verifier_email (char ch[20])
{int i;int x = 0;int y = 0; int z = 0; int b = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] == '@' )
    x =x+ 1 ;
    if (ch[i] == '.' )
    b =b+ 1 ;
    if (ch[i] == ' ' )
    y = 1 ;}
    if (ch [0]=='@' || ch[strlen(ch)-1]=='@' || ch[strlen(ch)-1]=='.' )
        z =1;
   if ( x == 1 && y == 0 && z == 0 && b >0) return 1;
    else return 0;
}
int verifier_lettre (char ch[20])
{int i;int x = 0;
   for (i=0 ; i < strlen (ch) ; i++)
   {if (ch[i] != 'a' && ch[i] != 'b' && ch[i] != 'c' && ch[i] != 'd' &&ch[i] != 'e' &&ch[i] != 'f' &&ch[i] != 'g' &&ch[i] != 'h' &&ch[i] != 'i' &&ch[i] != 'g' &&ch[i] != 'k'&&ch[i] != 'l'&&ch[i] != 'm'&&ch[i] != 'n'&&ch[i] != 'o'&&ch[i] != 'p'&&ch[i] != 'g'&&ch[i] != 'q'&&ch[i] != 'r'&&ch[i] != 's'&&ch[i] != 't'&&ch[i] != 'u'&&ch[i] != 'v'&&ch[i] != 'w'&&ch[i] != 'x'&&ch[i] != 'z'&&ch[i] != 'y'  )
    x = 1 ;}
   if ( x == 0 ) return 1;
    else return 0;
}




commande meulleur_client()
{

commande m;
int xx=0; 
FILE *f;

commande c;

f=fopen("commande.txt","r");


 while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d %d %d %d \n",c.cinalh,c.nomalh,c.prenomalh,&c.moutons,&c.vaches,&c.poules,&c.chevales,&c.fruits,&c.legumes,&c.da.journ,&c.da.moinn,&c.da.annen,&c.facture)!=EOF)

    { if (xx < c.facture) { m=c; xx = c.facture; } }
return m;

}

