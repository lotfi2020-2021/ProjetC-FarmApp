#include <gtk/gtk.h>


void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_Retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_reto_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_Chercher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ar_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_re_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_pr_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ar1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_re1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_pr1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button57_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_prod_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mat_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_pro1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mat1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_button58_ch1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


void
on_button58_ch_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button59_ch_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_ch_clicked                (GtkButton       *button,
                                        gpointer         user_data);
