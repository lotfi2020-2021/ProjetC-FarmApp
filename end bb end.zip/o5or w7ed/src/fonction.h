#include<gtk/gtk.h>


typedef struct 
{
char id[30];
char nom[30];
char quantite[30];
char marque[30];
char prix[30];
char tache[150];
char en[100];
char type[100];
}equi;

void ajouter(equi e);
void afficher(GtkWidget *liste);
void supprimer(equi e);
void chercher( char *idchercher,GtkWidget *liste); 
void modifier(equi e);
