#ifdef HAVE_CONFIG_H
#include <config.h>
#endif



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include<gtk/gtk.h>

enum
{ 
	EID,
	ENOM,
	EQUANTITE,
	EMARQUE,
	EPRIX,
	ETACHE,
	EEN,
	ETYPE,
	COLUMNS,
	
	
};



///////////////////////////////////////////////
void ajouter(equi e)
{
FILE *f;
f = fopen("equipement.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s \n",e.id,e.nom,e.quantite,e.marque,e.prix,e.tache,e.en,e.type);

fclose(f);
}
}
///////////////////////////////////////////////
void afficher(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char nom[30];
	char quantite[30];
	char marque[30];
	char prix[30];
	char tache[150];
	char en[100];
	char type[100];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =
 gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("quantite", renderer, "text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);  

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("marque", renderer, "text",EMARQUE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("prix", renderer, "text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("tache", renderer,"text",ETACHE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	column = gtk_tree_view_column_new_with_attributes("en", renderer, "text",EEN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,	 G_TYPE_STRING,	 G_TYPE_STRING,	 G_TYPE_STRING);
	f=fopen("equipement.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("equipement.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,quantite,marque,prix,tache,en,type)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id, ENOM, nom, EQUANTITE, quantite, EMARQUE, marque, EPRIX, prix, ETACHE, tache,EEN, en,ETYPE, type,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}

}




///////////////////////////////////////////////
void supprimer(equi e)
///////////////////////////////////////////////

{	equi e2;
	FILE *f,*g;
	f=fopen("equipement.txt","r");
	g=fopen("users2.txt","w");
	if( f==NULL  || g==NULL )
		return;
	else
	{
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",e2.id,e2.nom,e2.quantite,e2.marque,e2.prix,e2.tache,e2.en,e2.type)!=EOF)
		{
			if (strcmp(e.id,e2.id)!=0 || strcmp(e.nom,e2.nom)!=0 || strcmp(e.quantite,e2.quantite)!=0 || strcmp(e.marque,e2.marque)!=0 || strcmp(e.prix,e2.prix)!=0 || strcmp(e.tache,e2.tache)|| strcmp(e.en,e2.en)!=0|| strcmp(e.type,e2.type)!=0)
			fprintf(g,"%s %s %s %s %s %s %s %s \n",e2.id,e2.nom,e2.quantite,e2.marque,e2.prix,e2.tache,e2.en,e2.type);
		}		fclose(f);
		fclose(g);
	
remove("equipement.txt");
rename("users2.txt","equipement.txt");
	}


}
	




void modifier(equi e1)
{
equi e;
int trouve=0;
FILE *f,*f1;
f=NULL;
f1=NULL;
f=fopen("equipement.txt","r");
f1=fopen("equipement3.txt","w+");
if(f!=NULL)
{while((fscanf(f,"%s %s %s %s %s %s %s %s ",e.id,e.nom,e.quantite,e.marque,e.prix,e.tache,e.en,e.type)!=EOF))
{
if(strcmp(e.id,e1.id)==0)
{trouve=1;

fprintf(f1,"%s %s %s %s %s %s %s %s \n",e1.id,e1.nom,e1.quantite,e1.marque,e1.prix,e1.tache,e1.en,e1.type);
}
else
{fprintf(f1,"%s %s %s %s %s %s %s %s \n",e.id,e.nom,e.quantite,e.marque,e.prix,e.tache,e.en,e.type);
}
}
}

fclose(f);
fclose(f1);
remove("equipement.txt");
rename("equipement3.txt","equipement.txt");


}


void chercher( char idchercher[10],GtkWidget *liste)

{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char nom[30];
	char quantite[30];
	char marque[30];
	char prix[30];
	char tache[150];
	char en[100];
	char type[100];
	store==NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);

	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =
 gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("quantite", renderer, "text",EQUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);  

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("marque", renderer, "text",EMARQUE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = 
gtk_tree_view_column_new_with_attributes("prix", renderer, "text",EPRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("tache", renderer,"text",ETACHE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	column = gtk_tree_view_column_new_with_attributes("en", renderer, "text",EEN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,	 G_TYPE_STRING,	 G_TYPE_STRING,	 G_TYPE_STRING);
	f=fopen("equipement.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("equipement.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",id,nom,quantite,marque,prix,tache,en,type)!=EOF)
		{if (strcmp(id,idchercher)==0)
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id, ENOM, nom, EQUANTITE, quantite, EMARQUE, marque, EPRIX, prix, ETACHE, tache,EEN, en,ETYPE, type,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}

}






