#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
char t[150];
char t1[150];
char xy[150];
char xz[150];
equi e;
void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{


equi e;
int o=0;

GtkWidget *erreur_id_ch,*erreur_nom_ch,*erreur_quantite_ch,*erreur_marque_ch,*erreur_prix_ch;
GtkWidget *input1, *input2, *input3, *input4, *input5, *en;
GtkWidget *fenetre_ajouter;

fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");

input1=lookup_widget(objet,"Id_ch");
input2=lookup_widget(objet,"Nom_ch");
input3=lookup_widget(objet,"Quantite_ch");
input4=lookup_widget(objet,"Marque_ch");
input5=lookup_widget(objet,"Prix_ch");
en=lookup_widget(objet, "combobox1_ch");
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(e.tache,t);
strcpy(e.en,gtk_combo_box_get_active_text(GTK_COMBO_BOX(en)));
strcpy(e.type,xy);
erreur_id_ch=lookup_widget(fenetre_ajouter,"erreur_id_ch");
erreur_nom_ch=lookup_widget(fenetre_ajouter,"erreur_nom_ch");
erreur_quantite_ch=lookup_widget(fenetre_ajouter,"erreur_quantite_ch");
erreur_marque_ch=lookup_widget(fenetre_ajouter,"erreur_marque_ch");
erreur_prix_ch=lookup_widget(fenetre_ajouter,"erreur_prix_ch");

if (strcmp(e.id,"")==0)
{o=1;
gtk_widget_show(erreur_id_ch);
}
else
{gtk_widget_hide(erreur_id_ch);
}
if (strcmp(e.nom,"")==0)
{o=1;
gtk_widget_show(erreur_nom_ch);
}
else
{gtk_widget_hide(erreur_nom_ch);
}
if (strcmp(e.quantite,"")==0)
{o=1;
gtk_widget_show(erreur_quantite_ch);
}
else
{gtk_widget_hide(erreur_quantite_ch);}
if (strcmp(e.marque,"")==0)
{o=1;
gtk_widget_show(erreur_marque_ch);
}
else
{gtk_widget_hide(erreur_marque_ch);}
if (strcmp(e.prix,"")==0)
{o=1;
gtk_widget_show(erreur_prix_ch);
}
else
{gtk_widget_hide(erreur_prix_ch);}
if (o==0)
{ajouter(e);}

}





void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;

fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");

gtk_widget_destroy(fenetre_ajouter);
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();

gtk_widget_show(fenetre_afficher);


treeview1_ch=lookup_widget(fenetre_afficher,"treeview1_ch");

afficher(treeview1_ch);
}


void
on_Modifier_clicked                    (GtkWidget       *objet,
                                        gpointer        user_data)              
{      
GtkWidget *fenetre_modifier;
GtkWidget *fenetre_afficher;

fenetre_afficher=lookup_widget(objet,"fenetre_afficher");

gtk_widget_destroy(fenetre_afficher);
fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
fenetre_modifier=create_fenetre_modifier();

gtk_widget_show(fenetre_modifier);
equi e1; 
FILE *f;
f=fopen("equipement.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %s \n",e1.id,e1.nom,e1.quantite,e1.marque,e1.prix,e1.tache,e1.en,e1.type)!=EOF)
{
if (strcmp(e.id,e1.id)==0)
{			gtk_entry_set_text(GTK_ENTRY(lookup_widget(fenetre_modifier,"entry1_ch")),e1.id); 
			gtk_entry_set_text(GTK_ENTRY(lookup_widget(fenetre_modifier,"entry2_ch")),e1.nom); 
			gtk_entry_set_text(GTK_ENTRY(lookup_widget(fenetre_modifier,"entry3_ch")),e1.quantite);
			gtk_entry_set_text(GTK_ENTRY(lookup_widget(fenetre_modifier,"entry4_ch")),e1.marque); 
			gtk_entry_set_text(GTK_ENTRY(lookup_widget(fenetre_modifier,"entry5_ch")),e1.prix); 
		 
}
                                 
}
}


void
on_button_Retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *fenetre_ajouter;


fenetre_afficher=lookup_widget(objet,"fenetre_afficher");

gtk_widget_destroy(fenetre_afficher);
fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
fenetre_ajouter=create_fenetre_ajouter();

gtk_widget_show(fenetre_ajouter);
GtkWidget *erreur_id_ch,*erreur_nom_ch,*erreur_quantite_ch,*erreur_marque_ch,*erreur_prix_ch;

erreur_id_ch=lookup_widget(fenetre_ajouter,"erreur_id_ch");
erreur_nom_ch=lookup_widget(fenetre_ajouter,"erreur_nom_ch");
erreur_quantite_ch=lookup_widget(fenetre_ajouter,"erreur_quantite_ch");
erreur_marque_ch=lookup_widget(fenetre_ajouter,"erreur_marque_ch");
erreur_prix_ch=lookup_widget(fenetre_ajouter,"erreur_prix_ch");  
gtk_widget_hide(erreur_id_ch);  
gtk_widget_hide(erreur_nom_ch);  
gtk_widget_hide(erreur_quantite_ch);  
gtk_widget_hide(erreur_marque_ch);  
gtk_widget_hide(erreur_prix_ch);  
                           
}



void
on_button_reto_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;

fenetre_modifier=lookup_widget(objet,"fenetre_modifier");

gtk_widget_destroy(fenetre_modifier);
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();

gtk_widget_show(fenetre_afficher);


treeview1_ch=lookup_widget(fenetre_afficher,"treeview1_ch");

afficher(treeview1_ch);


}


void
on_button_Chercher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)

{

char idchercher[10];
GtkWidget *input1;
GtkWidget *gestion;
GtkWidget *treeview1_ch;
GtkWidget *fenetre_afficher;
input1=lookup_widget(objet,"entry7_ch");

strcpy(idchercher,gtk_entry_get_text(GTK_ENTRY(input1)));
gestion=lookup_widget(objet,"gestion");

gtk_widget_destroy(gestion);

//gtk_widget_show(fenetre_rechercher);


treeview1_ch=lookup_widget(objet,"treeview1_ch");



chercher(idchercher, treeview1_ch );

}




void
on_buttonmodif_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *input1, *input2, *input3, *input4, *input5, *en;
equi e;
input1=lookup_widget(objet,"entry1_ch");
input2=lookup_widget(objet,"entry2_ch");
input3=lookup_widget(objet,"entry3_ch");
input4=lookup_widget(objet,"entry4_ch");
input5=lookup_widget(objet,"entry5_ch");
en=lookup_widget(objet, "combobox_ch");

strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(e.tache,t1);
strcpy(e.en,gtk_combo_box_get_active_text(GTK_COMBO_BOX(en)));
strcpy(e.type,xz);
modifier(e);

}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* quantite;
	gchar* marque;
	gchar* prix;
	gchar* tache;
	gchar* en;
	gchar* type;	
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&quantite,3,&marque,4,&prix,5,&tache,6,&en,7,&type,-1);
		strcpy(e.id,id);
		strcpy(e.nom,nom);
		strcpy(e.quantite,quantite);
		strcpy(e.marque,marque);
		strcpy(e.prix,prix);
		strcpy(e.tache,tache);
		strcpy(e.en,en);
		strcpy(e.type,type);
		
		
	}

}







void
on_button56_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{{
GtkWidget *fenetre_rechercher;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;

fenetre_rechercher=lookup_widget(objet,"fenetre_rechercher");

gtk_widget_destroy(fenetre_rechercher);
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();

gtk_widget_show(fenetre_afficher);


treeview1_ch=lookup_widget(fenetre_afficher,"treeview1_ch");

afficher(treeview1_ch);


}


}


void
on_ar_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t,"arroser");
}

}


void
on_re_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t,"recolter");
}

}


void
on_pr_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t,"preparersol");
}

}

void
on_ar1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t1,"arroser");
}

}
void
on_re1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t1,"recolter");
}

}

void
on_pr1_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(t1,"preparersol");
}

}

void
on_button57_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
treeview1_ch=lookup_widget(fenetre_afficher,"treeview1_ch");
afficher(treeview1_ch);

}


void
on_prod_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xy,"produits");}

}


void
on_mat_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xy,"materiel");}

}



void
on_pro1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xz,"produits");}

}


void
on_mat1_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xz,"materiel");}

}


void
on_button58_ch1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *verif_ch;
GtkWidget *fenetre_afficher;
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
verif_ch=create_verif_ch();
gtk_widget_show(verif_ch);

}


void
on_button59_ch_clicked                 (GtkButton       *button,
					gpointer         user_data)
{GtkWidget *verif_ch;
GtkWidget *fenetre_afficher;
fenetre_afficher=create_fenetre_afficher();
verif_ch=lookup_widget(button,"verif_ch");
gtk_widget_destroy(verif_ch);
gtk_widget_show(fenetre_afficher);


}




void
on_button58_ch_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;
GtkWidget *verif_ch;
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);

verif_ch=create_verif_ch();

gtk_widget_show(verif_ch);

}



void
on_confirmer_ch_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer(e);
GtkWidget *fenetre_afficher;
GtkWidget *treeview1_ch;
GtkWidget *verif_ch;
verif_ch=lookup_widget(button,"verif_ch");
gtk_widget_destroy(verif_ch);

fenetre_afficher=create_fenetre_afficher();

gtk_widget_show(fenetre_afficher);
}

