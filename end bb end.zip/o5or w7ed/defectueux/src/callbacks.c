#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteurs.h"



void
on_YKbuttonAj_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *YKentryId,*YKentryMarq,*YKspinbuttonSeuilmin,*YKspinbuttonSeuilmax,*YKspinbuttonJour,*YKspinbuttonMois,*YKspinbuttonAnnee;
GtkWidget *Ajout_capteurs;
GtkWidget *YKcomboboxType;
Ajout_capteurs=lookup_widget(objet,"Ajout_capteurs");
capteur c;

Ajout_capteurs=lookup_widget(objet,"Ajout_capteurs");
YKentryId=lookup_widget(objet,"YKentryRef");
YKentryMarq=lookup_widget(objet,"YKentryMarq");
YKspinbuttonSeuilmin=lookup_widget(objet,"YKspinbuttonSeuilmin");
YKspinbuttonSeuilmax=lookup_widget(objet,"YKspinbuttonSeuilmax");
YKspinbuttonJour=lookup_widget(objet,"YKspinbuttonJour");
YKspinbuttonMois=lookup_widget(objet,"YKspinbuttonMois");
YKspinbuttonAnnee=lookup_widget(objet,"YKspinbuttonAnnee");

strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(YKentryId)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(YKentryMarq)));
c.seuil_min=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonSeuilmin));
c.seuil_max=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonSeuilmax));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonJour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonMois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonAnnee));
YKcomboboxType=lookup_widget(objet,"YKcomboboxType");
if(strcmp("Humidite",gtk_combo_box_get_active_text(GTK_COMBO_BOX(YKcomboboxType)))==0)
c.type=0;
else
c.type=1;
ajouter(c);
}


void
on_YKbuttonAfficher1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Ajout_capteurs;
GtkWidget *Affichage;
GtkWidget *treeview1;

Ajout_capteurs=lookup_widget(objet,"Ajout_capteurs");
gtk_widget_destroy(Ajout_capteurs);
Affichage=create_Affichage();

gtk_widget_show(Affichage);
treeview1=lookup_widget(Affichage,"treeview1");

affiche(treeview1,"capteurs.txt");

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* id;
gchar* marque;
gint seuil_min;
gint seuil_max;
gint type;
gint jour;
gint mois;
gint annee;
capteur c;
GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&marque,2,&seuil_min,3,&seuil_max,4,&type,5,&jour,6,&mois,7,&annee,-1);
strcpy(c.id,id);
strcpy(c.marque,marque);
c.seuil_min=seuil_min;
c.seuil_max=seuil_max;
c.date.jour=jour;
c.date.mois=mois;
c.date.annee=annee;
c.type=type;
supprimer1(c.id);
affiche(treeview,"capteurs.txt");
}

}


void
on_YKbuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Gestion_capteurs,*Affichage;
Affichage=lookup_widget(objet,"Affichage");
gtk_widget_destroy(Affichage);
Gestion_capteurs=create_Gestion_capteurs();
gtk_widget_show(Gestion_capteurs);

}







void
on_YKbuttonModifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Gestion_capteurs,*Modification;
	Gestion_capteurs=lookup_widget(objet,"Gestion_capteurs");
	gtk_widget_destroy(Gestion_capteurs);
	Modification=create_Modification();
	gtk_widget_show(Modification);

}


void
on_YKbuttonAjouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Gestion_capteurs,*Ajout_capteurs;
	Gestion_capteurs=lookup_widget(objet,"Gestion_capteurs");
	gtk_widget_destroy(Gestion_capteurs);
	Ajout_capteurs=create_Ajout_capteurs();
	gtk_widget_show(Ajout_capteurs);

}


void
on_YKbuttonAfficher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Gestion_capteurs,*Affichage,*treeview1;
	Gestion_capteurs=lookup_widget(objet,"Gestion_capteurs");
	gtk_widget_destroy(Gestion_capteurs);
	Affichage=create_Affichage();
	gtk_widget_show(Affichage);
	treeview1=lookup_widget(Affichage,"treeview1");
	affiche(treeview1,"capteurs.txt");

}


void
on_YKbuttonRech_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id;
	char id1[100];
	id=lookup_widget(objet,"entry1");
	strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
	GtkWidget *Affichage;
	GtkWidget *treeview1;
	Affichage=lookup_widget(objet,"Affichage");
	gtk_widget_destroy(Affichage);
	Affichage=lookup_widget(objet,"Affichage");
	Affichage=create_Affichage();
	gtk_widget_show(Affichage);
	treeview1=lookup_widget(Affichage,"treeview1");
	rechercher(treeview1,id1);

}


void
on_YKbuttonAfficher2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Modification,*Affichage,*treeview1;
	Modification=lookup_widget(objet,"Modification");
	gtk_widget_destroy(Modification);
	Affichage=create_Affichage();
	gtk_widget_show(Affichage);
	treeview1=lookup_widget(Affichage,"treeview1");
	affiche(treeview1,"capteurs.txt");
}


void
on_YKbuttonModmod_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *YKentryId,*YKentryMarq,*YKspinbuttonSeuilmin,*YKspinbuttonSeuilmax,*YKspinbuttonJour,*YKspinbuttonMois,*YKspinbuttonAnnee;
GtkWidget *Modification;
GtkWidget *YKcomboboxTypee;

capteur c;

Modification=lookup_widget(objet,"Modification");
YKentryId=lookup_widget(objet,"YKentryRefcaptmod");
YKentryMarq=lookup_widget(objet,"YKentryMarq1");
YKspinbuttonSeuilmin=lookup_widget(objet,"YKspinbuttonSeuilmin1");
YKspinbuttonSeuilmax=lookup_widget(objet,"YKspinbuttonSeuilmax1");
YKspinbuttonJour=lookup_widget(objet,"spinbutton1");
YKspinbuttonMois=lookup_widget(objet,"spinbutton2");
YKspinbuttonAnnee=lookup_widget(objet,"spinbutton3");

strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(YKentryId)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(YKentryMarq)));
c.seuil_min=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonSeuilmin));
c.seuil_max=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonSeuilmax));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonJour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonMois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(YKspinbuttonAnnee));
YKcomboboxTypee=lookup_widget(objet,"YKcomboboxTypee");
if(strcmp("Humidite",gtk_combo_box_get_active_text(GTK_COMBO_BOX(YKcomboboxTypee)))==0)
c.type=0;
else
c.type=1;
supprimer1(c.id);
ajouter(c);
}





void
on_ykcapt_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

     GtkWidget *output;
char texte [200]="";
{
FILE *f;
int i,j;
int deft=0;
int def[30];
int T[20];
char M[500][20];

int d;
char marque [20];
int n=deffectueux(T,"temperature.txt",-5,60.5);

int nbr=0;
f=fopen("marque.txt","r");
    if(f!=NULL)
 {
while(fscanf(f,"%s %d",&marque,&d)!=EOF)
{

          strcpy(M[nbr],marque);
          def[nbr]=0;
          nbr++;

  }
}
 fclose(f);
 i=0;
 while(i<nbr)
 {
     for(j=i+1;j<nbr;j++)
        {
            if(strcmp(M[i],M[j])==0)
            {strcpy(M[j],"00000");
            }
        }
        i++;
 }
 for(j=0;j<nbr;j++)
    {if(strcmp(M[j],"00000")!=0)
    {printf("/%s/",M[j]);
    deft++;}}

sprintf (texte,"la marque la plus defectueuse est %s ",M[n-1]);
output=lookup_widget(button,("yklabel42"));
gtk_label_set_text(GTK_LABEL(output),texte);

}
}

