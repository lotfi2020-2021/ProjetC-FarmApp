#include<gtk/gtk.h>
typedef struct 
{
int jour;
int mois;
int annee;
}date;

typedef struct 
{
char id[100];
char marque[100];
date date;
int type;
int seuil_min;
int seuil_max;
float val;
}capteur;


//gestion des capteurs
void supprimer(capteur c);
void modifier(capteur c);
void ajouter(capteur c);
void rechercher(GtkWidget *liste,char id[50]);
void affiche(GtkWidget *liste,char file[50]);
void supprimer1(char id[100]);

//fct de la deuxieme tache:la marque ayant le plus de capteurs defectueux
int deffectueux (int iden [], char *fichier, float minv , float maxv );

