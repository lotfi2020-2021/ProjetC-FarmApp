#include <gtk/gtk.h>


void
on_YKbuttonAj_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_YKbuttonAfficher1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_YKbuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);




void
on_YKbuttonModifier_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_YKbuttonAjouter_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_YKbuttonAfficher_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_YKbuttonRech_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_YKbuttonAfficher2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_YKbuttonModmod_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ykcapt_clicked                        (GtkButton       *button,
                                        gpointer         user_data);
