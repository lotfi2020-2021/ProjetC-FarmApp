#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "amous.h"
char xamous[20];char xamous1[20];
Capteur u;
void
on_button_connecteramous_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *loginam, *mdpam ;
char useram[20];
char paswam[20];

char useram1[20];
char paswam1[20];
int trouve;
loginam=lookup_widget (button,"entry_nomamous");
mdpam=lookup_widget (button,"entry_passwordamous");

strcpy(useram, gtk_entry_get_text(GTK_ENTRY(loginam)));
strcpy(paswam, gtk_entry_get_text(GTK_ENTRY(mdpam)));
FILE *f;


f=fopen("user.txt","r+");

while(fscanf(f,"%s %s\n",useram1,paswam1)!=EOF)
{
if((strcmp(useram,useram1)==0)&&(strcmp(paswam,paswam1)==0))
{
GtkWidget *authentificationam;
authentificationam=create_window_gestionamous();
gtk_widget_show (authentificationam);

GtkWidget *window_adminamous;
window_adminamous=lookup_widget(button,"window_adminamous");

gtk_widget_destroy (window_adminamous);

}
}
}

void
on_button_capteur_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window_gestionamous;
window_gestionamous=lookup_widget(button,"window_gestionamous");
gtk_widget_destroy (window_gestionamous);
GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);


GtkWidget *treeview1_amous;

treeview1_amous=lookup_widget(authentificationam,"treeview1_amous");

afficher_capteur(treeview1_amous);
GtkWidget *treeview2_amous;

treeview2_amous=lookup_widget(button,"treeview2_amous");

afficher_capteur(treeview2_amous);
}


void
on_button_actualiseramous_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window_capteur_accueil;

GtkWidget *treeview1_amous;

treeview1_amous=lookup_widget(button,"treeview1_amous");

afficher_capteur(treeview1_amous);
}


void
on_button_ajouteramous_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window_capteur_accueil;
window_capteur_accueil=lookup_widget(button,"window_capteur_accueil");
gtk_widget_destroy(window_capteur_accueil);
GtkWidget *authentificationam;
authentificationam=create_window_ajoutcapteur();
gtk_widget_show (authentificationam);
}


void
on_button_supprimeramous_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_capteur_accueil;
window_capteur_accueil=lookup_widget(button,"window_capteur_accueil");
gtk_widget_destroy(window_capteur_accueil);
GtkWidget *confurmer_amous;
confurmer_amous=create_confurmer_amous();
gtk_widget_show (confurmer_amous);
}


void
on_button_modifieramous_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_capteur_accueil;
window_capteur_accueil=lookup_widget(button,"window_capteur_accueil");
gtk_widget_destroy(window_capteur_accueil);
GtkWidget *window_modifieramous;
window_modifieramous=create_window_modifieramous();
gtk_widget_show (window_modifieramous);
}


void
on_button_rechercheramous_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

char cher[20];
GtkWidget *entry_rechercheramous;
entry_rechercheramous=lookup_widget(button,"entry_rechercheramous");
strcpy(cher, gtk_entry_get_text(GTK_ENTRY(entry_rechercheramous)));
/*GtkWidget *window_capteur_accueil;
window_capteur_accueil=lookup_widget(button,"window_capteur_accueil");
gtk_widget_destroy(window_capteur_accueil);
GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);*/
GtkWidget *treeview1_amous;

treeview1_amous=lookup_widget(button,"treeview1_amous");

chercher_capteur(treeview1_amous,cher);
}



void
on_button_ajoutercapteur_clicked       (GtkWidget *objet_graphique, gpointer user_data)
{


GtkWidget *id, *marque, *nom, *windowA;

GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;



Capteur c;

marque=lookup_widget(objet_graphique,"combobox_marqueamous");

id = lookup_widget (objet_graphique,"entry_idcapteur");

nom = lookup_widget (objet_graphique,"entry_nomcapteur");

Jour=lookup_widget(objet_graphique,"spinbutton_jouramous");
Mois=lookup_widget(objet_graphique,"spinbutton_moisamous");
Annee=lookup_widget(objet_graphique,"spinbutton_anneeamous");

c.dm.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Jour));
c.dm.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Mois));
c.dm.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Annee));

strcpy(c.marqueam, gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));

strcpy(c.idam, gtk_entry_get_text(GTK_ENTRY(id)));

strcpy(c.nomam, gtk_entry_get_text(GTK_ENTRY(nom)));

strcpy(c.tacheam,xamous);

ajouter_capteur(c);
GtkWidget *window_ajoutcapteur;
window_ajoutcapteur=lookup_widget(objet_graphique,"window_ajoutcapteur");
gtk_widget_destroy(window_ajoutcapteur);	
GtkWidget *window_ajoutsuccamous;
window_ajoutsuccamous=create_window_ajoutsuccamous();
gtk_widget_show (window_ajoutsuccamous);
}

void
on_button_annulerajoutamous_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window_ajoutcapteur;
window_ajoutcapteur=lookup_widget(button,"window_ajoutcapteur");
gtk_widget_destroy(window_ajoutcapteur);
GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);


}


void
on_button_succescontinueramous_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajoutsuccamous;
window_ajoutsuccamous=lookup_widget(button,"window_ajoutsuccamous");
gtk_widget_destroy(window_ajoutsuccamous);

GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);


}


void
on_button_modenregistreramous_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id, *marque, *nom, *windowA, *tache;

GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;



Capteur c;

marque=lookup_widget(button,"comboboxentry_modmarkeamous");

id = lookup_widget (button,"entry_modidamous");

nom = lookup_widget (button,"entry_modidamous");

Jour=lookup_widget(button,"spinbutton_modjouramous");
Mois=lookup_widget(button,"spinbutton_modmoisamous");
Annee=lookup_widget(button,"spinbutton_modanneeamous");

c.dm.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Jour));
c.dm.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Mois));
c.dm.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Annee));

strcpy(c.marqueam, gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));

strcpy(c.idam, gtk_entry_get_text(GTK_ENTRY(id)));

strcpy(c.nomam, gtk_entry_get_text(GTK_ENTRY(nom)));

strcpy(c.tacheam,xamous1);

modifier_capteur (c , u);

GtkWidget *window_modifieramous;
window_modifieramous=lookup_widget(button,"window_modifieramous");
gtk_widget_destroy(window_modifieramous);
GtkWidget *suuc_modifier_amous;
suuc_modifier_amous=create_suuc_modifier_amous();
gtk_widget_show (suuc_modifier_amous);
}


void
on_button_modannuleramous_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window_modifieramous;
window_modifieramous=lookup_widget(button,"window_modifieramous");
gtk_widget_destroy(window_modifieramous);
GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);

}


void
on_radiobutton_temperature_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous,"temperature");}
}


void
on_radiobutton_volume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous,"volume");}
}


void
on_radiobutton_poids_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous,"poids");}
}


void
on_radiobutton_modtempamous_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous1,"temperature");}
}


void
on_radiobutton_modvolumeamous_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous1,"volume");}
}


void
on_radiobutton_modpoidsamous_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{strcpy(xamous1,"poids");}
}


void
on_treeview1_amous_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* marque;
	gchar* date;
	gchar* tache;
		
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&marque,3,&tache,4,&date,-1);
		strcpy(u.idam,id);
		
		
		
		
		
	}
}


void
on_confurmersppamous_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_capteur(u);
GtkWidget *suuc_modifier_amous;
suuc_modifier_amous=lookup_widget(button,"confurmer_amous");
gtk_widget_destroy(suuc_modifier_amous);

GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);
}


void
on_annuler_co_amous_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *suuc_modifier_amous;
suuc_modifier_amous=lookup_widget(button,"confurmer_amous");
gtk_widget_destroy(suuc_modifier_amous);

GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);
}


void
on_con_mod_amous_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *confurmer_amous;
confurmer_amous=lookup_widget(button,"suuc_modifier_amous");
gtk_widget_destroy(confurmer_amous);

GtkWidget *authentificationam;
authentificationam=create_window_capteur_accueil();
gtk_widget_show (authentificationam);
}


void
on_treeview2_amous_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* marque;
	gchar* date;
	gchar* tache;
		
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&marque,3,&tache,4,&date,-1);
		strcpy(u.idam,id);
		strcpy(u.tacheam,tache);
		
		
		
		
		
	}
}


void
on_save_amous_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
Capteur d;
GtkWidget *spinbuttonval_amous;
spinbuttonval_amous=lookup_widget (button,"spinbuttonval_amous");
d.valam=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbuttonval_amous));

GtkWidget *calendar;
int jj,mm,aa;
calendar=lookup_widget(button,"calendar1_amous");
gtk_calendar_get_date (GTK_CALENDAR(calendar),
                       &aa,
                       &mm,
                       &jj);
mm=mm+1;
strcpy(d.idam,u.idam);
strcpy(d.tacheam,u.tacheam);
d.dm.jour=jj;
d.dm.mois=mm;
d.dm.annee=aa;
ajouter_save_capteur (d);
}


void
on_act_val_amous_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview2_amous;

treeview2_amous=lookup_widget(button,"treeview2_amous");

afficher_capteur(treeview2_amous);
}


void
on_capteur_alar_amous_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview3_amous;

treeview3_amous=lookup_widget(button,"treeview3_amous");

afficher_capteur_alar(treeview3_amous);
}

