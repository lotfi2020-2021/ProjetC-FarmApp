#include <gtk/gtk.h>


void
on_button_connecteramous_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_capteur_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiseramous_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouteramous_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimeramous_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifieramous_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercheramous_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajoutercapteur_clicked       (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_annulerajoutamous_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_succescontinueramous_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modenregistreramous_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modannuleramous_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_temperature_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_volume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_poids_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modtempamous_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modvolumeamous_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modpoidsamous_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_amous_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_confurmersppamous_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_co_amous_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_con_mod_amous_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_amous_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_save_amous_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_val_amous_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_capteur_alar_amous_clicked          (GtkButton       *button,
                                        gpointer         user_data);
