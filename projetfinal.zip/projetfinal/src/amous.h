#include <gtk/gtk.h>
#ifndef  FONCTIONS_H_
#define  FONCTIONS_H_
typedef struct
{int jour;
int mois;
int annee;
}data;

typedef struct
{
char nomam[10];
char idam[10];
char marqueam[10];
char tacheam[20];
int valam;

data dm;
}Capteur;

int verif(char log[]);
void supprimer_capteur(Capteur c);
void afficher_capteur(GtkWidget *liste);
void ajouter_capteur (Capteur c);
void modifier_capteur (Capteur a , Capteur o);
void supprimer_capteur(Capteur p1);
void chercher_capteur(GtkWidget *liste,char cha[20]);
void ajouter_save_capteur (Capteur c);
void afficher_capteur_alar(GtkWidget *liste);
#endif
