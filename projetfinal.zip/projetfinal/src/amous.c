#include "amous.h"
#include <stdio.h> 

#include <string.h>
#include <gtk/gtk.h>


enum 
{
	IDDAM,
	NOMAM,
	MARQUEAM,
	TACHEAM,
	DATEAM,
	COLUMNSAM
};





int verif(char log[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[100];
f=fopen("capteurs.txt","r+");
if (f!=NULL)
{
while(fscanf(f,"%s",ch1)!=EOF)
{
if(strcmp(ch1,log)==0)
trouve=1;
}
fclose(f);
}
return (trouve);
}


////////////////////////////
////////////////////////////


void afficher_capteur(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

char damous[20];
store=NULL;

Capteur c1;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" ID",renderer,"text",IDDAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOMAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",MARQUEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" tache",renderer,"text",TACHEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" date",renderer,"text",DATEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	store=gtk_list_store_new(COLUMNSAM, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("capteurs.txt","r+");
	
	if(f==NULL)
		{
		return;
		}
	else 
		{
		f=fopen("capteurs.txt","a+");
		while(fscanf(f,"%s %s %s %s %s \n",c1.idam,c1.marqueam,c1.nomam,c1.tacheam,damous)!=EOF)
			{
			gtk_list_store_append(store,&iter);
			
			gtk_list_store_set(store,&iter,IDDAM,c1.idam,NOMAM,c1.nomam,MARQUEAM,c1.marqueam,TACHEAM,c1.tacheam,DATEAM,damous, -1);

			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);		
		}
	}
}




void chercher_capteur(GtkWidget *liste,char cha[20])
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

char damous[20];
store=NULL;

Capteur c1;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" ID",renderer,"text",IDDAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOMAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",MARQUEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" tache",renderer,"text",TACHEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" date",renderer,"text",DATEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	store=gtk_list_store_new(COLUMNSAM, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("capteurs.txt","r+");
	
	if(f==NULL)
		{
		return;
		}
	else 
		{
		f=fopen("capteurs.txt","a+");
		while(fscanf(f,"%s %s %s %s %s\n",c1.idam,c1.marqueam,c1.nomam,c1.tacheam,damous)!=EOF)
			{if (strcmp(cha,c1.idam)==0){
			gtk_list_store_append(store,&iter);
				gtk_list_store_set(store,&iter,IDDAM,c1.idam,NOMAM,c1.nomam,MARQUEAM,c1.marqueam,TACHEAM,c1.tacheam,DATEAM,damous, -1);

			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);		
		}
	}
}

////////////////////////////
////////////////////////////






void ajouter_capteur (Capteur c)
{
FILE *f=NULL;
f=fopen("capteurs.txt","a+");

if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f,"%s %s %s %s %d/%d/%d \n",c.idam,c.marqueam,c.nomam,c.tacheam,c.dm.jour,c.dm.mois,c.dm.annee);
fclose(f);

}
}


void modifier_capteur (Capteur a , Capteur o)
{
Capteur p;
FILE *f;
FILE *g;
char damous[10];

f=fopen("capteurs.txt","r");

g=fopen("newwca.txt","w");


      while(fscanf(f,"%s %s %s %s %s \n",p.idam,p.marqueam,p.nomam,p.tacheam,damous)!=EOF)
    {
	if(strcmp(o.idam,p.idam)==0)
		{
fprintf(g,"%s %s %s %s %d/%d/%d \n",a.idam,a.marqueam,a.nomam,a.tacheam,a.dm.jour,a.dm.mois,a.dm.annee);
		}
else
{fprintf(g,"%s %s %s %s %s \n",p.idam,p.marqueam,p.nomam,p.tacheam,damous);
}


}

fclose(f);
fclose(g);
remove("capteurs.txt");
rename("newwca.txt","capteurs.txt");
}


void supprimer_capteur(Capteur p1)
{
FILE *f;
FILE *f1;
char damous[10];
	    Capteur p;
	   
f=fopen("capteurs.txt","r");
f1=fopen("ancienam.txt","w+");
if(f==NULL,f1==NULL)
 {
     return;
}else
while(fscanf(f,"%s %s %s %s %s \n",p.idam,p.marqueam,p.nomam,p.tacheam,damous)!=EOF)
{
if(strcmp(p1.idam,p.idam)!=0)
fprintf(f1,"%s %s %s %s %s \n",p.idam,p.marqueam,p.nomam,p.tacheam,damous);
}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancienam.txt","capteurs.txt");
}



void ajouter_save_capteur (Capteur c)
{
FILE *f=NULL;
f=fopen("savecap.txt","a+");

if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f,"%s %s %d %d/%d/%d \n",c.idam,c.tacheam,c.valam,c.dm.jour,c.dm.mois,c.dm.annee);
fclose(f);

}
}




void afficher_capteur_alar(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char xaa[20]="";
char damous[20];
store=NULL;

Capteur c1;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" ID",renderer,"text",IDDAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Tache",renderer,"text",NOMAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Valeur",renderer,"text",MARQUEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" date lecture",renderer,"text",TACHEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	
	store=gtk_list_store_new(COLUMNSAM, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("savecap.txt","r+");
	
	if(f==NULL)
		{
		return;
		}
	else 
		{
		f=fopen("savecap.txt","a+");
		while(fscanf(f,"%s %s %d %s \n",c1.idam,c1.tacheam,&c1.valam,damous)!=EOF)
			{ if (c1.valam > 30){

sprintf(xaa,"%d",c1.valam);
			gtk_list_store_append(store,&iter);
			
			gtk_list_store_set(store,&iter,IDDAM,c1.idam,NOMAM,c1.tacheam,MARQUEAM,xaa,TACHEAM,damous, -1);

			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);		
		}
	}
}
